<?php

namespace Facebook\WebDriver;

/**
 * @coversDefaultClass \Facebook\WebDriver\WebDriverNavigation
 */
class WebDriverNavTest extends WebDriverTestCase
{
    /**
     * @covers ::__construct
     * @covers ::to
     */
    public function testShouldNavigateToUrl()
    {
        $this->driver->navigate()->to($this->getTestPageUrl('signup.php'));

        $this->assertStringEndsWith('/signup.php', $this->driver->getCurrentURL());
    }

    /**
     * @covers ::back
     * @covers ::forward
     */
    public function testShouldNavigateBackAndForward()
    {
        $this->driver->get($this->getTestPageUrl('signup.php'));
		
		***i need a id for the login link***
        $linkElement = $this->driver->findElement(WebDriverBy::id('login'));

        $linkElement->click();

        $this->driver->wait()->until(
            WebDriverExpectedCondition::urlContains('login.php')
        );

        $this->driver->navigate()->back();

        $this->driver->wait()->until(
            WebDriverExpectedCondition::urlContains('signup.php')
        );

        $this->driver->navigate()->forward();

        $this->driver->wait()->until(
            WebDriverExpectedCondition::urlContains('login.php')
        );
    }
	
	
	

    /**
     * @covers ::refresh
     */
    public function testShouldRefreshPage()
    {
        $this->driver->get($this->getTestPageUrl('signup_form.php'));

        // Change input element content, to make sure it was refreshed (=> cleared to original value)
        $inputElement = $this->driver->findElement(WebDriverBy::name('name'));
        $inputElementOriginalValue = $inputElement->getAttribute('value');
        $inputElement->clear()->sendKeys('New value');
        $this->assertSame('New value', $inputElement->getAttribute('value'));

        $this->driver->navigate()->refresh();

        $this->driver->wait()->until(
            WebDriverExpectedCondition::stalenessOf($inputElement)
        );

        $inputElementAfterRefresh = $this->driver->findElement(WebDriverBy::name('name'));

        $this->assertSame($inputElementOriginalValue, $inputElementAfterRefresh->getAttribute('value'));
    }
}