package com.mycompany.app;


import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import org.junit.Before;
import org.junit.Test;
import org.junit.After;
import static org.junit.Assert.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Integration UI test for PHP App.
 */

public class AppTest
{
	WebDriver driver; 
	WebDriverWait wait; 
	String indexUrl = "https://pacapaca.sitict.net/index.php";
	String loginUrl = "https://pacapaca.sitict.net/login.php";
	String signupUrl = "https://pacapaca.sitict.net/signup.php";
	String validEmail = "wzchua33@gmail.com";
	String invalidEmail = "none@example.com";
	String validPassword = "Qwerty123";
	String invalidPassword = "password";
	String name = "Test faiz";
	String email = "test@gmail.com";
	String password = "Zxcvb123";
	String date = "29101995";
	List<WebElement> list = new ArrayList<WebElement>();

    @Before
    public void setUp() { 
		driver = new HtmlUnitDriver(); 
		wait = new WebDriverWait(driver, 15); 
	} 

    @After
    public void tearDown() { 
		driver.quit(); 
	}
	
	
    @Test
    public void testRegisterWithValidInformation() 
		throws InterruptedException {
		//get web page
		driver.get(signupUrl);
		//wait until page is loaded or timeout error
		wait.until(ExpectedConditions.titleContains("PacaPaca - Sign Up")); 
		
		//enter input
		driver.findElement(By.name("name")).sendKeys(name);
		driver.findElement(By.name("email")).sendKeys(email);
		driver.findElement(By.name("BDay")).click();
		driver.findElement(By.name("BDay")).sendKeys(date);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("confirmation")).sendKeys(password);
		//click submit
		driver.findElement(By.id("submit")).submit();
	    
		//check result 
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.navigate().refresh();
		String expectedResult = "PacaPaca - Success"; 
		boolean isResultCorrect = wait.until(ExpectedConditions.titleContains(expectedResult)); 
		assertTrue(isResultCorrect == true); 
	}
	
    @Test
    public void testLoginWithValidEmailInvalidPassword() 
		throws InterruptedException { 

		//get web page
		driver.get(loginUrl);
		//wait until page is loaded or timeout error
		wait.until(ExpectedConditions.titleContains("PacaPaca - Log In")); 

		//enter input
		driver.findElement(By.name("email")).sendKeys(validEmail);
		driver.findElement(By.name("password")).sendKeys(invalidPassword);
		
		//click submit
		driver.findElement(By.name("submit")).submit();
		
		//check result
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		By errorMsgId = By.name("info");
		driver.findElement(By.name("info"));
		WebElement test = driver.findElement(By.name("info"));
		boolean test1 = test.isDisplayed();
		assertTrue(test1 == true);
		
	}

    @Test
    public void testLoginWithValidEmailValidPassword() 
		throws InterruptedException { 

		//get web page
		driver.get(loginUrl);
		//wait until page is loaded or timeout error
		wait.until(ExpectedConditions.titleContains("PacaPaca - Log In")); 

		//enter input
		driver.findElement(By.name("email")).sendKeys(validEmail);
		driver.findElement(By.name("password")).sendKeys(validPassword);
		//click submit
		//submit button no  name
		driver.findElement(By.name("submit")).submit();
	
		//check result 
		String expectedResult = "PacaPaca - Login Verification"; 
		boolean isResultCorrect = wait.until(ExpectedConditions.titleContains(expectedResult)); 
		assertTrue(isResultCorrect == true); 
	}
		
	
	@Test
	public void testNavigateToSignIn()
		throws InterruptedException{
		
		//get web page
		driver.get(indexUrl);
		//wait until page is loaded or timeout error
		wait.until(ExpectedConditions.titleContains("PacaPaca")); 
		//click submit
		driver.findElement(By.name("login")).click();
		
		
	
		//check result 
		String expectedResult = "PacaPaca - Log In"; 
		boolean isResultCorrect = wait.until(ExpectedConditions.titleContains(expectedResult)); 
		assertTrue(isResultCorrect == true); 
		}
		
	@Test
	public void testNavigateToSignUp()
		throws InterruptedException{
			
		
		//get web page
		driver.get(indexUrl);
		//wait until page is loaded or timeout error
		wait.until(ExpectedConditions.titleContains("PacaPaca")); 
		//click submit
		driver.findElement(By.name("signup")).click();
		
		
	
		//check result 
		String expectedResult = "PacaPaca - Sign Up"; 
		boolean isResultCorrect = wait.until(ExpectedConditions.titleContains(expectedResult)); 
		assertTrue(isResultCorrect == true); 
		}
	
	@Test
	public void testNavigateFromSignUpToSignIn()
		throws InterruptedException{
			
		
		//get web page
		driver.get(signupUrl);
		//wait until page is loaded or timeout error
		wait.until(ExpectedConditions.titleContains("PacaPaca - Sign Up")); 
		//click submit
		driver.findElement(By.name("signin2")).click();
		
		
	
		//check result 
		String expectedResult = "PacaPaca - Log In"; 
		boolean isResultCorrect = wait.until(ExpectedConditions.titleContains(expectedResult)); 
		assertTrue(isResultCorrect == true); 
		}
	
	@Test
	public void testNavigateFromLogInToSignUp()
		throws InterruptedException{
			
		
		//get web page
		driver.get(loginUrl);
		//wait until page is loaded or timeout error
		wait.until(ExpectedConditions.titleContains("PacaPaca - Log In")); 
		//click submit
		driver.findElement(By.name("createAcct")).click();
		
		
	
		//check result 
		String expectedResult = "PacaPaca - Sign Up"; 
		boolean isResultCorrect = wait.until(ExpectedConditions.titleContains(expectedResult)); 
		assertTrue(isResultCorrect == true); 
		}


	@Test
	public void testNavigateFromLogInToForgetPassword()
		throws InterruptedException{
			
		
		//get web page
		driver.get(loginUrl);
		//wait until page is loaded or timeout error
		wait.until(ExpectedConditions.titleContains("PacaPaca - Log In")); 
		//click submit
		driver.findElement(By.name("resetAcct")).click();
		
		
	
		//check result 
		String expectedResult = "PacaPaca - Reset Password"; 
		boolean isResultCorrect = wait.until(ExpectedConditions.titleContains(expectedResult)); 
		assertTrue(isResultCorrect == true); 
		}
 

}
