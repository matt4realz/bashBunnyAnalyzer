<?php

	/**
	 * helpers.php
	 *
	 * Helper functions.
	 */
	require_once("config.php");


	/**
	 * Validates password requirements
	 * */
	function pwReq($password) {
		$pattern = "/^(?=.*[a-z])(?=.*[A-Z]).{8,}$/";

		if (preg_match($pattern, $password) == 1)
			return true;

		return false;
	}
	
	////////NEW FUNCTIONS HERE//////////
	
	//santizize password
	function pwSanitizeBeforeChange($password){
		//cannot contain symbols such as <,>,'," and ,
		$pattern = "/\<|\>|\'|\"|\,/";
		if(preg_match($pattern, $password) == 1)
			 return true;
		 
		 return false;
	}
	
	function pwSanitizeAfterChange($password_new){
		//cannot contain symbols such as <,>,'," and ,
		$pattern = "/\<|\>|\'|\"|\,/";
		if(preg_match($pattern, $password_new) == 1)
			 return true;
		 
		 return false;
	}
	
	//santize email
	function emailSanitize($email){
		//cannot contain symbols other than @ sign
		$pattern = "/\`|\~|\!|\#|\%|\^|\&|\*|\(|\)|\+|\=|\[|\{|\]|\}|\||\\|\'|\<|\,|\>|\?|\/|\-|\_|\"|\;|\:/";
		if(preg_match($pattern, $email) == 1)
			 return true;
		 
		 return false;
	}
	
	//santize name
	function nameSanitize($name){
		//cannot contain special characters
		$pattern = "/\`|\~|\!|\@|\#|\$|\%|\^|\&|\*|\(|\)|\+|\=|\[|\{|\]|\}|\||\\|\'|\<|\,|\.|\>|\?|\/|\-|\_|\"|\;|\:/";
		if(preg_match($pattern, $name) == 1)
			 return false;
		 
		 return true;
	}

	/**
	 * Validates email address
	 * */
	function validateEmail($email) {
		 $pattern = "/\S+@\S+\.\S+/";

		if (preg_match($pattern, $email) == 1)
			return true;

		return false;
	}
	
	/**
	  * Validates unit number
	  **/
	 function validateUnitNumber($unitNumber){
		 $pattern = "/[0-9]/";
		 
		 if(preg_match($pattern, $unitNumber) == 1)
			 return true;
		 
		 return false;
	 }
	 
	 function validatePostalCode($postalCode){
		 $pattern = "/[0-9]/";
		 
		 if(preg_match($pattern, $postalCode) == 1)
			 return true;
		 
		 return false;
	 }
	 
	 function validateAddress($address){
		 $pattern = "/\`|\~|\!|\@|\#|\$|\%|\^|\&|\*|\(|\)|\+|\=|\[|\{|\]|\}|\||\\|\'|\<|\,|\.|\>|\?|\/|\-|\_|\"|\;|\:/";
		 
		 if(preg_match($pattern, $address) == 1)
			 return true;
		 
		 return false;
	 }
	 
	 /**
	 * helpers.php
	 *
	 * Helper functions.
	 */
	require_once("config.php");
	
	// for PHPMailer
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;
	
	
	/**
	 * Sends email using the PHPMailer library
	 * https://github.com/PHPMailer/PHPMailer
	 * 
	 * returns true on success and false on failure
	 * */
	function sendMail($recipient, $subject, $content) {
		$mail = new PHPMailer(true);

		// get email account credentials
        $path = __DIR__ . "/../config.json";
		if (is_file($path)) {
            $contents = file_get_contents($path);
			if ($contents !== false) {
				$config = json_decode($contents, true);
			}
        }

        if (!isset($config["email"])) {
            return false;
        }
		
		try {
			//Server settings
			$mail->isSMTP();                                            
			$mail->Host       = $config["email"]["host"];                    
			$mail->SMTPAuth   = true;                                   
			$mail->Username   = $config["email"]["username"];                     
			$mail->Password   = $config["email"]["password"];                               
			$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         
			$mail->Port       = 587;                                    

			//Recipients
			$mail->setFrom($config["email"]["username"], 'PacaPaca-noreply');
			$mail->addAddress($recipient);

			// Content
			$mail->isHTML(true);                                  
			$mail->Subject = $subject;
			$mail->Body    = $content;
			$mail->AddEmbeddedImage('img/title-small.png', 'logo');

			if ($mail->send()) {
				return true;
			}
			
		} catch (Exception $e) {
			return false;
		}
	}
	
	
	/**
	 * Generate OTP used for login and password reset
	 */
	function generateOTP() {
		return strtoupper(bin2hex(openssl_random_pseudo_bytes(4))); 
	}

	/**
	 * Facilitates debugging by dumping contents of argument(s)
	 * to browser.
	 */
	function dump() {
		$arguments = func_get_args();
		require("../views/dump.php");
		exit;
	}

	/**
	 * Redirects user to location, which can be a URL or
	 * a relative path on the local host.
	 */
	function redirect($location) {
		if (headers_sent($file, $line)) {
			trigger_error("HTTP headers already sent at {$file}:{$line}", E_USER_ERROR);
		}
		header("Location: {$location}");
		exit;
	}

	/**
	 * Renders view, passing in values.
	 */
	function render($view, $values = []) {
		// if view exists, render it
		if (file_exists("../views/{$view}")) {
			
			// remove image from values if exists
			if (isset($values["images"])) {
				$images = $values["images"];
				unset($values["images"]);
			}
			
			// html encode values
			array_walk_recursive($values, function (&$value) {
				$value = htmlentities($value);
			});
			
			// add images back to values
			if (!empty($images)) {
				foreach($images as $key => $value) {
					$values["items"][$key]["pacaItemImage"] = $value["pacaItemImage"];
				}
			}
			
			// extract variables into local scope
			extract($values);
			
			// render view (between header and footer)
			require("../views/header.php");
			require("../views/{$view}");
			require("../views/footer.php");
			exit;
		} 

		// else error
		else {
			trigger_error("Invalid view: {$view}", E_USER_ERROR);
		}
	}

?>
