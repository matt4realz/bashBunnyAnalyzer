<?php 

// configuration
require_once("config.php");

class logging
{
	// create logs directory if does not exists
	public static function path() 
	{
		if (!file_exists("../logs/")) {
			mkdir("../logs/");
		}
	}
	
	// print log to text files base on events
	public static function type($case, $vars) {
		switch ($case) {  
		  case "OTP":
			
			if (!file_exists("../logs/OTP.txt")) {
				file_put_contents("../logs/OTP.txt", "Time			UserID 		Event 						IP Address\n");
			}
			
			if (isset($_SESSION["OTP_ID"])) 
				$id = $_SESSION["OTP_ID"];
			else
				$id = '';
			
			if ($vars[0] == 1) 
				$msg = date('Y-m-d H:i:s') . "	" . $id . "		OTP authentication succeeded for " . $vars[1] .	"		" . $_SERVER["REMOTE_ADDR"] . "\n";
			else 
				$msg = date('Y-m-d H:i:s') . "	" . $id . "		OTP authentication failed for " . $vars[1] .	"		" . $_SERVER["REMOTE_ADDR"] . "\n";
			
			
			file_put_contents("../logs/OTP.txt", $msg, FILE_APPEND);
			break;
			
		  case "profile":
		  
			if (!file_exists("../logs/profile.txt")) {
				file_put_contents("../logs/profile.txt", "Time			UserID 		Event\n");
			}
			$i = 0;
			foreach($vars[1] as $key => $value) {
				if ($i <3) {
					$vars[1][$i] = $vars[1][$key];
					unset($vars[1][$key]);
					$i++;
				}
			}
			
			$changes = [];
			foreach($vars[0] as $key => $value) {
				if ($vars[0][$key] != $vars[1][$key]) {
					if ($key == 0)
						$change = "Name: " . $vars[0][$key] . " --> " . $vars[1][$key] . ", ";
				 	else if ($key == 1)
						$change = "Email: " . $vars[0][$key] . " --> " . $vars[1][$key] . ", ";
					else if ($key == 2)
						$change = "Birthday: " . $vars[0][$key] . " --> " . $vars[1][$key];
					
					array_push($changes, $change);
				}
			}
			if (count($changes) != 3) {
				$changes[count($changes) - 1] = substr($changes[count($changes) - 1], 0, -2);
			}
			
			$msg = date('Y-m-d H:i:s') . "	" . $_SESSION["id"] . "		Profile details changed for " . implode($changes) . "\n";
			
			
			file_put_contents("../logs/profile.txt", $msg, FILE_APPEND);
			break;
			
		  case "payment":
			if (!file_exists("../logs/transactions.txt")) {
				file_put_contents("../logs/transactions.txt", "Time			UserID 			TransactionID			ItemID		Quantity	PaidAmount\n");
			}
			
			$itemID = "";
			$quantity = "";
			foreach($vars[0] as $keys => $values) {
				foreach($values as $key => $value) {
					if ($keys == 0) {
						$itemID = $itemID . $key;
						$quantity = $quantity . $value;
					}
					else {
						$itemID = $itemID . ", " . $key;
						$quantity = $quantity . ", " . $value;
					}
				}
			}
			
			$msg = date('Y-m-d H:i:s') . "	" . $_SESSION["id"] . "		" . $vars[1] . "	" . $itemID . "		" .	$quantity . "		S$" . $vars[2] . "\n";
			
			file_put_contents("../logs/transactions.txt", $msg, FILE_APPEND);
			break;

		  default:
			return;
		} 
	}
}

?>