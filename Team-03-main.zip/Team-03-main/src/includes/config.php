<?php

	/**
	 * config.php
	 *
	 * Configures app.
	 */
	// display errors, warnings, and notices
	ini_set("display_errors", true);
	error_reporting(E_ALL);

	// requirements
	require("helpers.php");
	require("db.php");
	require("logging.php");

	db::init(__DIR__ . "/../config.json");
	
	// PHPMailer
	require 'vendor/PHPMailer/src/Exception.php';
	require 'vendor/PHPMailer/src/PHPMailer.php';
	require 'vendor/PHPMailer/src/SMTP.php';
	
	// for stripe api configuration
	$path = __DIR__ . "/../config.json";
	if (is_file($path)) {
		$contents = file_get_contents($path);
		if ($contents !== false) {
			$config = json_decode($contents, true);
		}
	}
	define('STRIPE_API_KEY', $config["stripe"]["sk_test"]); 
	define('STRIPE_PUBLISHABLE_KEY', $config["stripe"]["pk_test"]);
	unset($config);
	
	// set default timezone
	date_default_timezone_set('Asia/Singapore');

	// enable sessions
	session_start();
	
	// log user out after 10 minutes of inactivity
	if(isset($_SESSION['timeout']) ) {
		$session_life = time() - $_SESSION['timeout'];
		if($session_life > 600) { 
			header("Location: logout.php"); 
		}
	}

	// update user's last active time
	if (isset($_SESSION["id"])) {
		$_SESSION["timeout"] = time();
	}
	
	// create directory for logs if does not exists
	logging::path();
	
	// sanitise all POST inputs
	$_POST  = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

	// require authentication for all pages except /index.php, /login.php, /logout.php, and /signup.php
	if (!in_array($_SERVER["PHP_SELF"], ["/index.php", "/login.php", "/logout.php", "/signup.php", "/reset.php"]))
	{
		if (empty($_SESSION["id"]))
		{
	    		redirect("/");
		}
	}

	// prevent user from viewing admin pages
	if (isset($_SESSION["role"])) {
		if ($_SESSION["role"] == 0) {
			if (in_array($_SERVER["PHP_SELF"], ["/adminPortal.php", "/itemManagement.php"])) {
				header($_SERVER["SERVER_PROTOCOL"]." 403 Forbidden", true, 403);
				redirect("/");
			}
		}
	}

?>
