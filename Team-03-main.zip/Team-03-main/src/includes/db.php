<?php

class db
    {
        private static $config;

        /**
         * Initializes library with JSON file at $path.
		 * Connect to database.
         */
        public static function init($path)
		{
			if (!isset(self::$config))
			{
				// ensure configuration file exists
				if (!is_file($path))
				{
					trigger_error("Could not find {$path}", E_USER_ERROR);
				}

				// read contents of configuration file
				$contents = file_get_contents($path);
				if ($contents === false)
				{
					trigger_error("Could not read {$path}", E_USER_ERROR);
				}

				// decode contents of configuration file
				$config = json_decode($contents, true);
				if (is_null($config))
				{
					trigger_error("Could not decode {$path}", E_USER_ERROR);
				}
				
				self::$config = $config;
			}
			
			if (!isset($conn))
			{
				$conn = mysqli_connect(self::$config["database"]["host"], self::$config["database"]["user"], self::$config["database"]["password"], self::$config["database"]["dbname"], self::$config["database"]["port"]);
				
				if ($conn->connect_error) 
				{
					die("Connection failed: " . $conn->connect_error);
				}
			}
		}
		
		/**
         * Executes SQL statement, possibly with parameters, returning
         * an array of all rows in result set or false on (non-fatal) error.
         */
        public static function query(/* $sql [, ... ] */)
        {
            // ensure library is initialized
            if (!isset(self::$config["database"]))
            {
                trigger_error("db is not initialized", E_USER_ERROR);
            }

            // ensure database is configured
            foreach (["host", "dbname", "password", "user"] as $key)
            {
                if (!isset(self::$config["database"][$key]))
                {
                    trigger_error("Missing value for database.{$key}", E_USER_ERROR);
                }
            }

            // SQL statement
            $sql = func_get_arg(0);
			
            // parameters, if any
            $parameters = array_slice(func_get_args(), 1);

            // try to connect to database
            static $handle;
            if (!isset($handle))
            {
                try
                {
                    // connect to database
                    $handle = new PDO(
                        "mysql:dbname=" . self::$config["database"]["dbname"] . ";host=" . self::$config["database"]["host"],
                        self::$config["database"]["user"],
                        self::$config["database"]["password"]
                    );
			$handle->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
                }
                catch (Exception $e)
                {
                    // trigger error
                    trigger_error($e->getMessage(), E_USER_ERROR);
                }
            }
			
			// replace placeholders with parameters
			$query = '';
			for($i = 0, $offset = 0; $i < count($parameters); $i++) {
				$parameters[$i] = "'$parameters[$i]'";
				
				if (($pos = strpos($sql, '?', $offset)) !== false){
					$query .= substr($sql, $offset, $pos-$offset) . $parameters[$i];
					$offset = $pos + 1;
				}
			}
			$query .= substr($sql, $offset).';';
			
            // execute query
            $statement = $handle->query($query);
            if ($statement === false)
            {
                //echo $query;
                trigger_error($handle->errorInfo()[2], E_USER_ERROR);
            }
   
            // if query was SELECT
            if ($statement->columnCount() > 0)
            {
                // return result set's rows
                return $statement->fetchAll(PDO::FETCH_ASSOC);
            }

            // if query was DELETE, INSERT, or UPDATE
            else
            {
                // return number of rows affected
                return $statement->rowCount();
            }
        }
	}
?>
