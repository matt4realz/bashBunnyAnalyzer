<?php

// configuration
require("../includes/config.php");


if ($_SERVER["REQUEST_METHOD"] == "GET") {
	$shopItems = db::query("SELECT * FROM pacashop");
	render("itemManagement_view.php", ["title" => "Item Management", "shopItems" => $shopItems]);
} 

else if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$shopItems = db::query("SELECT * FROM pacashop");
	
	if(isset($_POST["btnAddItem"])){
		$itemImage = "";
		
		// Check for empty values
		if(empty($_POST["itemName"]) || empty($_POST["itemDesc"]) || empty($_POST["itemPrice"]) || empty($_POST["itemStock"])){
			$error = "Please fill up all required fields";
			render("itemManagement_view.php", ["title" => "Item Management", "shopItems" => $shopItems, "error" => $error]);
		}
		
		// Check for file upload
		if (getimagesize($_FILES['itemImage']['tmp_name']) == false) {
			$error = "Please select an image";
			render("itemManagement_view.php", ["title" => "Item Management", "shopItems" => $shopItems, "error" => $error]);		
		} else {
			$itemImage = addslashes(file_get_contents($_FILES['itemImage']['tmp_name']));
		}
		
		if($_POST["selCategory"] == "women"){
			$itemCategory = 1;
		}else if($_POST["selCategory"] == "men"){
			$itemCategory = 2;
		}else{
			$itemCategory = 3;
		}
		
		// Add item into db
		$res = db::query("INSERT INTO pacashop (pacaItemName, pacaItemDescription, pacaItemPrice, pacaItemStock, pacaItemCategory, pacaItemImage) VALUES(?, ?, ?, ?, ?, ?)",
		$_POST["itemName"], $_POST["itemDesc"], $_POST["itemPrice"], $_POST["itemStock"], $itemCategory, $itemImage);
		
		if($res == 1){
			$shopItems = db::query("SELECT * FROM pacashop");
			render("itemManagement_view.php", ["title" => "Item Management", "shopItems" => $shopItems, "alert" => "New item added successfully/alert-success"]);
		}
	}
	
	if(isset($_POST["btnSave"])){
		$itemID = $_POST["editItemID"];
		
		// Check for empty values
		if(empty($_POST["editItemName"]) || empty($_POST["editItemDesc"]) || empty($_POST["editItemPrice"]) || empty($_POST["editItemStock"])){
			$editError = "Please fill up all required fields";
			render("itemManagement_view.php", ["title" => "Item Management", "shopItems" => $shopItems, "editError" => $editError]);
		}
		
		if($_POST["selEditCategory"] == "women"){
			$itemCategory = 1;
		}else if($_POST["selEditCategory"] == "men"){
			$itemCategory = 2;
		}else{
			$itemCategory = 3;
		}
		
		// Update item in db
		$res = db::query("Update pacashop SET pacaItemName = ?, pacaItemDescription = ?, pacaItemPrice = ?, pacaItemStock = ?, pacaItemCategory = ? WHERE pacaItemID = $itemID",
		$_POST["editItemName"], $_POST["editItemDesc"], $_POST["editItemPrice"], $_POST["editItemStock"], $itemCategory);
		
		if($res == 1){
			$shopItems = db::query("SELECT * FROM pacashop");
			render("itemManagement_view.php", ["title" => "Item Management", "shopItems" => $shopItems, "alert" => "Item updated successfully/alert-success"]);
		}
	}
	
	if(isset($_POST["btnCfmRemove"])){
		$itemID = $_POST["removeItemID"];
		// Remove item from db
		$res = db::query("DELETE FROM pacashop WHERE pacaItemID = $itemID");
		if($res == 1){
			$shopItems = db::query("SELECT * FROM pacashop");
			render("itemManagement_view.php", ["title" => "Item Management", "shopItems" => $shopItems, "alert" => "Item removed successfully/alert-success"]);
		}
	}
}

?>