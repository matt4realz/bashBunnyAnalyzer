<?php 
	// configuration
    require("../includes/config.php");
	render("index_view.php");

?>