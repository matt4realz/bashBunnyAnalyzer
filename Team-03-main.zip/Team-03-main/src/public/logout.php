<?php

// configuration
require("../includes/config.php");

// log out current user
$_SESSION = [];

// destroy session
session_destroy();

// redirect user
redirect("/");
?>
