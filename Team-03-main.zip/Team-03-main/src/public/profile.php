<?php

    // configuration
    require("../includes/config.php");
	
	if ($_SERVER["REQUEST_METHOD"] == "GET")
	{
		$rows = db::query("SELECT * FROM pacausrs WHERE usrID = ?", $_SESSION["id"]);
        
		// Get user info from db
		if (count($rows) == 1)
		{
			$row = $rows[0];
			$details = [$row['usrFullName'], $row['usrEmailAddr'], $row["usrBirthday"]];
			$_SESSION["details"] = $details;
			render("profile_form.php", ["title" => "Update Profile", "name" => $row['usrFullName'], "email" => $row['usrEmailAddr'], "bday" => $row["usrBirthday"]]);	
		}
	}
	
	else if ($_SERVER["REQUEST_METHOD"] == "POST")
	{	
		// check for empty inputs
		foreach ($_POST as $input)
		{
			if (empty($input))
				render("profile_form.php", ["title" => "Update Profile", "name" => $_SESSION["details"][0], "email" => $_SESSION["details"][1], "bday" => $_SESSION["details"][2], "alert" => "Please fill up all required fields./alert-danger"]);
		}
		
		if (isset($_POST["email"])) {
			if (!validateEmail($_POST["email"])) {
				render("profile_form.php", ["title" => "Update Profile", "name" => $_SESSION["details"][0], "email" => $_SESSION["details"][1], "bday" => $_SESSION["details"][2], "alert" => "Invalid email entered/alert-danger"]);
			}	
		}
		
		// prompt user for password for verification
		if (!isset($_POST["password"])) 
		{
			$_SESSION["profile"] = $_POST;
			render("confirmation.php", ["title" => "Update Profile"]);
		}
			
		// query database for user
		$rows = db::query("SELECT * FROM pacausrs WHERE usrID = ?", $_SESSION['id']);
		$row = $rows[0];
		$details = [$row['usrFullName'], $row['usrEmailAddr'], $row["usrBirthday"]];
		$_SESSION["details"] = $details;
		
		// verify password
		if (!password_verify($_POST["password"], $row["usrPwdHash"]))      
			render("confirmation.php", ["title" => "Update Profile", "alert" => "Invalid password/alert-danger"]);
		
		
		// update database
		$result = db::query("UPDATE pacausrs SET usrFullName = ?, usrEmailAddr = ?, usrBirthday = ? WHERE usrID = ?", 
			$_SESSION["profile"]["name"], $_SESSION["profile"]["email"], $_SESSION["profile"]["bday"], $_SESSION["id"]);
		
		if ($result == 1) 
		{
			// log user profile change
			logging::type("profile", [$_SESSION['details'], $_SESSION['profile']]);
			
			$row = $_SESSION['profile'];
			unset($_SESSION['details']);
			unset($_SESSION['profile']);
			render("profile_form.php", ["title" => "Update Profile", "name" => $row['name'], "email" => $row['email'], "bday" => $row["bday"], "alert" => "Profile updated successfully!/alert-success"]);
		
		}
		else 
		{
			$row = $_SESSION['profile'];
			unset($_SESSION['details']);
			unset($_SESSION['profile']);
			render("profile_form.php", ["title" => "Update Profile", "name" => $row['name'], "email" => $row['email'], "bday" => $row["bday"], "alert" => "No changes were made/alert-info"]);
		}
    }

?>