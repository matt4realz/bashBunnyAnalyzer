/**
 * scripts-footer.js
 * 
 * Global javascript and jQuery 
 * loaded at footer
**/


/**
 * Bootstrap alerts
 * https://getbootstrap.com/docs/4.0/components/alerts/
**/
if (document.getElementById("alert") !== null)
{
	var parts = document.getElementById("alert").innerHTML.split("/");
	alertMsg(parts[0], parts[1]);
}


// Bootstrap tooltip
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
 });
 
 
