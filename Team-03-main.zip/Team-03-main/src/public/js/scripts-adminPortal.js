$(document).ready(function(){
	$('.btnEditItem').on('click', function(){
		$('#editItemModal').modal('show');
		
		$tr = $(this).closest('tr');
        var data = $tr.children("td").map(function () {
            return $(this).text();
        }).get();

		$('#editItemID').val(data[0]);
		$('#editItemName').val(data[1]);
		$('#editItemDesc').val(data[2]);
		$('#editItemPrice').val(data[3].slice(0, 0) + data[3].slice(1, data[3].length));
		$('#editItemStock').val(data[4]);
		
	});
	
	$('.btnRemoveItem').on('click', function(){
		$('#removeItemModal').modal('show');
		
		$tr = $(this).closest('tr');
        var data = $tr.children("td").map(function () {
            return $(this).text();
        }).get();

		$('#removeItemID').val(data[0]);
		
	});
});