/**
 * scripts-header.js
 * 
 * Global javascript and jQuery
**/


/**
 * Bootstrap datepicker
 * https://bootstrap-datepicker.readthedocs.io/en/latest/
**/
$(document).ready(function() {
	let [month, date, year] = (new Date()).toLocaleDateString().split("/")
	var now = date + '/' + month + '/' + year;
	
	$('.datepicker').datepicker({
		format: "dd/mm/yyyy",
		orientation: "top",
		defaultDate: now,
		autoclose: true
	});
})


/**
 * Validates all form inputs 
**/
function validate(form) 
{	
	// for alert
	var message = '';
	
	// check for empty inputs by elements name
	for (i = 0; i < form.length-1; i++) 
	{ 
		if (form[i].value === "") 
		{
			form[i].style.borderColor = 'red';
			form[i].style.borderWidth = '2px';
			message = "Please fill up all required fields";
			event.preventDefault();
		}
		else
		{
			form[i].style.borderColor = 'green';
			form[i].style.borderWidth = '2px';
		}
	}
	
	// Ensure dropdown is selected
	if (document.getElementById("dropdown") !== null)
	{
		var option = document.getElementById("dropdown");
		if (option.value === "") 
		{
			option.style.borderColor = 'red';
			option.style.borderWidth = '2px';
			message = "Please fill up all required fields";
			event.preventDefault();
		}
		else
		{
			option.style.borderColor = 'green';
			option.style.borderWidth = '2px';
		}
	}
	
	// validate email in form
	if ("email" in form)
	{	
		var re = /\S+@\S+\.\S+/;
			
		if (!re.test(form["email"].value))
		{
			form[form["email"].getAttribute("name")].style.borderColor = 'red';
			form[form["email"].getAttribute("name")].style.borderWidth = '2px';
			if (message === '')
				message = "Email is invalid";
	
			event.preventDefault();
		}
		else
		{
			form[form["email"].getAttribute("name")].style.borderColor = 'green';
			form[form["email"].getAttribute("name")].style.borderWidth = '2px';
		}
	}
	
	
	// validate password requirements 
	if (document.getElementById("passReq") !== null)
	{
		var password = document.getElementById("passReq");
		
		var re = /^(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
		
		if (!re.test(password.value))
		{
			password.style.borderColor = 'red';
			password.style.borderWidth = '2px';
			if (message === '')
				message = "Password must be at least 8 characters and contain an uppercase and lowercase character.";
			
			event.preventDefault();
		}
		else
		{
			password.style.borderColor = 'green';
			password.style.borderWidth = '2px';
		}
	}
	
	// ensure passwords matches 
	if (document.getElementById("confirmation") !== null)
	{
		var password = document.getElementById("passReq");
		var confirmation = document.getElementById("confirmation");
		
		if (password.value !== confirmation.value || confirmation.value === "")
		{
			confirmation.style.borderColor = 'red';
			confirmation.style.borderWidth = '2px';
			if (message === '')
				message = "Password does not match";
			
			event.preventDefault();
		}
		else
		{
			confirmation.style.borderColor = 'green';
			confirmation.style.borderWidth = '2px';
		}
	}
	
	// validate all dates in form, if any
	
	if (message !== '')
		alertMsg(message, "alert-danger");
}


/**
 * Display bootstrap alert messages
 * https://getbootstrap.com/docs/4.0/components/alerts/
**/
function alertMsg(message, type)
{
	element = document.getElementById("info");
	element.innerHTML = message;
	
	element.classList.add(type);
	element.classList.add("show");
}


function getID(id) {
    userID = id;
}


function post(path, params, method) {
    // Set method to post by default if not specified.
	method = method || "post"; 
	params = JSON.parse(params);
	
    var form = document.createElement("form");
    form.setAttribute("method", method);
    form.setAttribute("action", path);
	
	if ('userID' in params) {
		params["userID"] = userID;
	}
	
    for(var key in params) {
		var hiddenField = document.createElement("input");
		hiddenField.setAttribute("type", "hidden");
		hiddenField.setAttribute("name", key);
		hiddenField.setAttribute("value", params[key]);

		form.appendChild(hiddenField);        
    }
	
    document.body.appendChild(form);
    form.submit();
}
