<?php

// configuration
require("../includes/config.php");
	
if ($_SERVER["REQUEST_METHOD"] == "GET") {

} 
else if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if(isset($_POST["btnViewDetails"])){
		// Retrieve item details by item id
		$itemID = $_POST["btnViewDetails"];
		$items = db::query("SELECT * FROM pacashop WHERE pacaItemID = $itemID");
		
		$images = [];
		foreach($items as $key => $value) {
			array_push($images, array("pacaItemImage" => $value["pacaItemImage"]));
			unset($items[$key]["pacaItemImage"]);
		}
			
		render("itemDetails_view.php", ["title" => "Item Details", "items" => $items, "images" => $images]);
	}
	
	if(isset($_POST["btnAddToCart"])){
		$usrID = $_SESSION["id"];
		$itemID = $_POST["btnAddToCart"];
		$quantity = $_POST["selQuantity"];
		
		// Query db for item name and price
		$rows = db::query("SELECT pacaItemName, pacaItemPrice FROM pacashop WHERE pacaItemID = $itemID");
		
		if (count($rows) == 1) {
			$row = $rows[0];
			$itemName = $row["pacaItemName"];
			$itemPrice = $row["pacaItemPrice"];
			$totalPrice = $itemPrice * $quantity;
			$paymentStatus = 0;
		
			// Add cart item into db
			$res = db::query("INSERT INTO pacatransaction (usrID, pacaItemID, pacaItemName, quantity, pacaItemPrice, totalPrice, paymentStatus) VALUES(?, ?, ?, ?, ?, ?, ?)",
			$usrID, $itemID, $itemName, $quantity, $itemPrice, $totalPrice, $paymentStatus);
			
			if($res == 1){
				redirect("/cart.php");
			}
		
		}
		
	}
}
?>
