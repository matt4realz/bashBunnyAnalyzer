<?php

// configuration
require("../includes/config.php");


if ($_SERVER["REQUEST_METHOD"] == "GET") {
	// Get all accounts from db
	$accounts = db::query("SELECT * FROM pacausrs");
	render("adminPortal_view.php", ["title" => "Admin Portal", "accounts" => $accounts]);
} 

else if ($_SERVER["REQUEST_METHOD"] == "POST") { 
	$accounts = db::query("SELECT * FROM pacausrs");
	
	// Delete user account
	if (isset($_POST["delete"])) { 
		db::query("DELETE FROM token WHERE userID = ?", $_POST['userID']);
		db::query("DELETE FROM pacausrs WHERE usrID = ?", $_POST['userID']);
		
		$accounts = db::query("SELECT * FROM pacausrs");
		render("adminPortal_view.php", ["title" => "Admin Portal", "accounts" => $accounts, "alert" => "Account deleted successfully/alert-success"]);
	}
	
	if(isset($_POST["btnAddAcc"])){

		if (empty($_POST["fullName"]) || empty($_POST["birthday"]) || empty($_POST["pwd"]) || empty($_POST["cfmPwd"])){
			$error = "Please fill up all required fields";
			render("adminPortal_view.php", ["title" => "Admin Portal", "accounts" => $accounts, "error" => $error]);
		}
		
		if (!validateEmail($_POST["emailAddr"])){
			$error = "Invalid email";
			render("adminPortal_view.php", ["title" => "Admin Portal", "accounts" => $accounts, "error" => $error]);
		
		}else if (!pwReq($_POST["pwd"])){
			$error = "Password does not meets requirements";
			render("adminPortal_view.php", ["title" => "Admin Portal", "accounts" => $accounts, "error" => $error]);
		
		}else if ($_POST["pwd"] != $_POST["cfmPwd"]){
			$error = "Password does not match";
			render("adminPortal_view.php", ["title" => "Admin Portal", "accounts" => $accounts, "error" => $error]);
		
		}else {
			$check = db::query("SELECT * FROM pacausrs WHERE usrEmailAddr = ?", $_POST['emailAddr']);
			
			if (!empty($check)) {
				$error = "Email already exists";
				render("adminPortal_view.php", ["title" => "Admin Portal", "accounts" => $accounts, "error" => $error]);
			 
			}else {
				if($_POST["selAccessRight"] == "admin"){
					$accessRight = 1;
				}else{
					$accessRight = 0;
				}
				
				// add user to db
				$res = db::query("INSERT INTO pacausrs (usrFullName, usrEmailAddr, usrPwdHash, usrBirthday, UsrIsAdmin) VALUES(?, ?, ?, ?, ?)",
						$_POST["fullName"], $_POST["emailAddr"], password_hash($_POST["pwd"], PASSWORD_DEFAULT), $_POST["birthday"], $accessRight);
						
				$row = db::query("SELECT * FROM pacausrs WHERE usrEmailAddr = ?", $_POST['emailAddr'])[0];
				$OTP = generateOTP();
				db::query("INSERT INTO token (userID, OTP) VALUES(?, ?)", $row["usrID"], $OTP);
				
				if ($res == 1){
					$accounts = db::query("SELECT * FROM pacausrs");
					
					render("adminPortal_view.php", ["title" => "Admin Portal", "accounts" => $accounts, "alert" => "New account added successfully/alert-success"]);
				}
			}
		}
	}
}

?>
