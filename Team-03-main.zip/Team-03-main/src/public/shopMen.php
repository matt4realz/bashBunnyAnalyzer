<?php

// configuration
require("../includes/config.php");
	
if ($_SERVER["REQUEST_METHOD"] == "GET") {
	
	// get items for kids
	$items = db::query("SELECT * FROM pacashop WHERE pacaItemCategory = 2");

	$images = [];
	foreach($items as $key => $value) {
		array_push($images, array("pacaItemImage" => $value["pacaItemImage"]));
		unset($items[$key]["pacaItemImage"]);
	}
	
	render("shopMen_view.php", ["title" => "Shop Men", "items" => $items, "images" => $images]);

} 
else if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
}
?>