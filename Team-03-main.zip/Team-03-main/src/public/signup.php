<?php

// configuration
require("../includes/config.php");


if ($_SERVER["REQUEST_METHOD"] == "GET") {
    render("signup_form.php", ["title" => "Sign Up"]);

} else if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	// check for empty inputs
	foreach ($_POST as $input)
	{
		if (empty($input))
			render("signup_form.php", ["title" => "Sign Up", "alert" => "Please fill up all required fields/alert-danger"]);
	}
	
	if (!validateEmail($_POST["email"]))
		render("signup_form.php", ["title" => "Sign Up", "alert" => "Invalid email/alert-danger"]);
	
	else if (nameSanitize($_POST["name"]))
		render("signup_form.php", ["title" => "Sign Up", "alert" => "Invalid name/alert-danger"]);
	
	else if (!pwReq($_POST["password"]))
		render("signup_form.php", ["title" => "Sign Up", "alert" => "Password does not meets requirements/alert-danger"]);
	
	else if ($_POST["password"] != $_POST["confirmation"])
        render("signup_form.php", ["title" => "Sign Up", "alert" => "Password does not match/alert-danger"]);
	
	else if (pwSanitizeBeforeChange($_POST["password"]))
		render("signup_form.php", ["title" => "Sign Up", "alert" => "Password does not meet requirements/alert-danger"]);
	
	else if (!emailSanitize($_POST["email"]))
		render("signup_form.php", ["title" => "Sign Up", "alert" => "Invalid email/alert-danger"]);
	
    else {
        $check = db::query("SELECT * FROM pacausrs WHERE usrEmailAddr = ?", $_POST['email']);
		
		if (!empty($check)) 
			render("signup_form.php", ["title" => "Sign Up", "alert" => "Email already exists/alert-danger"]);
         
		else {
            // add user to db
            $res = db::query("INSERT INTO pacausrs (usrFullName, usrEmailAddr, usrPwdHash, usrBirthday) VALUES(?, ?, ?, ?)",
                    $_POST["name"], $_POST["email"], password_hash($_POST["password"], PASSWORD_DEFAULT), $_POST["BDay"]);
            
            if ($res == 1){
				$row = db::query("SELECT * FROM pacausrs WHERE usrEmailAddr = ?", $_POST['email'])[0];
				
				$OTP = generateOTP();
				db::query("INSERT INTO token (userID, OTP) VALUES(?, ?)", $row["usrID"], $OTP);
				
				// send OTP to user's email for login
				$content = "<p>
								Dear ". $row["usrFullName"] . ", 
								<br>
								<br>
								You have recently registered for an account with PacaPaca.
								<br>
								Please enter the following OTP when prompted during login.
								<br>
								<br>
								<b>OTP: " . $OTP . "</b>
								<br>
								<br>
								Thank you for shopping with us!
								<br>
								<img src='cid:logo'>
								<br>
								<br>
								<br>
								<small>If this was not you, no further action is required on your part.</small>
							</p>";
							
				
				sendMail($_POST['email'], 'Account Registration', $content);
				
				render("signup_success.php", ["title" => "Success"]);
            }
        }
    }
}