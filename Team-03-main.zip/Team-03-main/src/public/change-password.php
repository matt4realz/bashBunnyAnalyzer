<?php

    // configuration
    require("../includes/config.php"); 
        
    if ($_SERVER["REQUEST_METHOD"] == "GET")
	{
		render("confirmation.php", ["title" => "Change Password"]);	
    }
	
	if ($_SERVER["REQUEST_METHOD"] == "POST")
	{	

		
		// query database for user
		$rows = db::query("SELECT * FROM pacausrs WHERE usrID = ?", $_SESSION['id']);
		$row = $rows[0];
		
		// verify password
		if (isset($_POST["password"]))
		{
			if (!password_verify($_POST["password"], $row["usrPwdHash"]))      
				render("confirmation.php", ["title" => "Update Profile", "alert" => "Invalid password/alert-danger"]);
		}
		
		// render change password form
		if (!isset($_POST["password_new"])) 
		{
			render("change_pw.php", ["title" => "Change Password", "change_pw" => true]);
		}
		
		//check for invalid fields
		if(pwSanitizeAfterChange($_POST["password_new"])){
				render("change_pw.php", ["title" => "Change Password", "change_pw" => true, "alert" => "Password does not meets requirements/alert-danger"]);
		}
		
		// check if new password meets requirements 
		if (!pwReq($_POST["password_new"]))
			render("change_pw.php", ["title" => "Change Password", "change_pw" => true, "alert" => "Password does not meets requirements/alert-danger"]);
		
		// check if new password matches confirmation
		if ($_POST["password_new"] != $_POST["confirmation"])
			render("change_pw.php", ["title" => "Change Password", "change_pw" => true, "alert" => "Passwords does not match/alert-danger"]);
		
		// update database
		$result = db::query("UPDATE pacausrs SET usrPwdHash = ? WHERE usrID = ?", password_hash($_POST["password_new"], PASSWORD_DEFAULT), $_SESSION["id"]);
		
		// inform user
		render("change_pw.php", ["title" => "Change Password", "change_pw" => true, "alert" => "Password changed successfully!/alert-success"]);
	}

?>