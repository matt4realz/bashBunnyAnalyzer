<?php

	// configuration
	require("../includes/config.php");
	include_once ("../includes/config.php");

	if ($_SERVER["REQUEST_METHOD"] == "GET") {

	}else if ($_SERVER["REQUEST_METHOD"] == "POST"){
		$usrID = $_SESSION["id"];
		$statusMsg = ''; 
		$ordStatus = 'error'; 
		$currency = "SGD";
		$status = 0;
		$totalPrices = db::query("SELECT totalPrice FROM pacatransaction WHERE usrID = $usrID AND paymentStatus = $status");
		// Check whether stripe token is not empty 
		if(!empty($_POST['stripeToken'])){ 
		
			//Check for invalid fields
			if(!validateUnitNumber($_POST["unitNumber"])){
				render("payment_view.php", ["title" => "Payment", "totalPrices" => $totalPrices, "alert" => "Please enter a valid unit number/alert-danger"]);
			}
			
			if(!validatePostalCode($_POST["postalCode"])){
				render("payment_view.php", ["title" => "Payment", "totalPrices" => $totalPrices, "alert" => "Please enter a valid postal code/alert-danger"]);
			}
			
			if(!validateAddress($_POST["Address"])){
				render("payment_view.php", ["title" => "Payment", "totalPrices" => $totalPrices, "alert" => "Please enter a valid address/alert-danger"]);
			}
			
			if(empty($_POST['name'])){
				render("payment_view.php", ["title" => "Payment", "totalPrices" => $totalPrices, "alert" => "Please enter name on card/alert-danger"]);
			}
			
			if(!validateEmail($_POST["email"])){
				render("payment_view.php", ["title" => "Payment", "totalPrices" => $totalPrices, "alert" => "Please enter a valid email address/alert-danger"]);
			}
			
			// Retrieve stripe token, card and user info from the submitted form data 
			$token  = $_POST['stripeToken']; 
			$name = $_POST['name']; 
			$email = $_POST['email']; 
			 
			// Include Stripe PHP library 
			require_once 'stripe-php/init.php'; 
			 
			// Set API key 
			\Stripe\Stripe::setApiKey(STRIPE_API_KEY); 
			 
			// Add customer to stripe 
			try {  
				$customer = \Stripe\Customer::create(array( 
					'email' => $email, 
					'source'  => $token 
				)); 
			}catch(Exception $e) {  
				$api_error = $e->getMessage();  
			} 
			 
			if(empty($api_error) && $customer){  
				
				// Convert price to cents 
				$total = 0;
				foreach($totalPrices as $price){
					$total += $price["totalPrice"];
				}
				$totalPrice = $total + 3;
				$totalPriceCents = ($totalPrice*100); 
				 
				// Charge a credit or a debit card 
				try {  
					$charge = \Stripe\Charge::create(array( 
						'customer' => $customer->id, 
						'amount'   => $totalPriceCents, 
						'currency' => $currency, 
						'description' => "PacaPaca payment transaction"
					)); 
				}catch(Exception $e) {  
					$api_error = $e->getMessage();  
				} 
				 
				if(empty($api_error) && $charge){ 
				 
					// Retrieve charge details 
					$chargeJson = $charge->jsonSerialize(); 
				 
					// Check whether the charge is successful 
					if($chargeJson['amount_refunded'] == 0 && empty($chargeJson['failure_code']) && $chargeJson['paid'] == 1 && $chargeJson['captured'] == 1){ 
						// Payment status
						$payment_status = $chargeJson['status']; 
			  
								
						// If the order is successful 
						if($payment_status == 'succeeded'){
							
							// Transaction details  
							$transactionID = $chargeJson['balance_transaction']; 
							$paidAmount = $chargeJson['amount']; 
							$paidAmount = ($paidAmount/100); 
							$pStatus = 1;
							
							$res = db::query("UPDATE pacatransaction SET txnId = ? WHERE usrID = $usrID AND paymentStatus = $status",
							$transactionID);
							
							// for logging
							$items = [];
							
							if($res > 0){
								$itemIDs = db::query("SELECT pacaItemID FROM pacatransaction WHERE txnId = '$transactionID'");
								foreach($itemIDs as $itemID){
								//	$qtyToRemove = 0;
									$id = $itemID["pacaItemID"];
									$quantities = db::query("SELECT sum(quantity) FROM pacatransaction WHERE pacaItemID = $id AND paymentStatus = $status");
									foreach($quantities as $quantity){
										$qtyToRemove = $quantity["sum(quantity)"];
										$updateQty = db::query("UPDATE pacashop SET pacaItemStock = pacaItemStock - $qtyToRemove WHERE pacaItemID = $id");
										
										array_push($items, array($id => $qtyToRemove));
									}
								}
								$updatePaymentStatus = db::query("UPDATE pacatransaction SET paymentStatus = ? WHERE usrID = $usrID AND paymentStatus = $status", $pStatus);
								if($updatePaymentStatus > 0){
									
									// log transaction details
									$vars = [$items, $transactionID, $paidAmount];
									logging::type("payment", $vars);
									
									render("paymentSuccess_view.php", ["title" => "Payment Success", "transactionID" => $transactionID, "paidAmount" => $paidAmount]);
								}
								
							}
						}else{ 
							render("payment_view.php", ["title" => "Payment", "totalPrices" => $totalPrices, "alert" => "Your Payment has Failed!/alert-danger"]);
						} 
						
					}else{ 
						render("payment_view.php", ["title" => "Payment", "totalPrices" => $totalPrices, "alert" => "Transaction has been failed!/alert-danger"]);
					} 
				}else{ 
					render("payment_view.php", ["title" => "Payment", "totalPrices" => $totalPrices, "alert" => "Charge creation failed! $api_error/alert-danger"]);
				} 
			}else{  
				render("payment_view.php", ["title" => "Payment", "totalPrices" => $totalPrices, "alert" => "Invalid card details! $api_error/alert-danger"]);
			}
			
		}else{ 
			render("payment_view.php", ["title" => "Payment", "totalPrices" => $totalPrices, "alert" => "Error on form submission/alert-danger"]);
		} 
		
	}

?>
