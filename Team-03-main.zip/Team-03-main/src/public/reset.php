<?php

// configuration
require("../includes/config.php");


if ($_SERVER["REQUEST_METHOD"] == "GET") {
    render("reset_form.php", ["title" => "Reset Password"]);

} else if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	// post request from change_pw.php
	if (isset($_POST["reset"])) {
		
		// validate inputs
		if (!isset($_POST["password"]) || !isset($_POST["confirmation"])) {
			render("change_pw.php", ["title" => "Reset Password", "verified" => true, "alert" => "Please fill up all required fields/alert-danger"]);
		}
		
		if (!pwReq($_POST["password"]))
			render("change_pw.php", ["title" => "Reset Password", "verified" => true, "alert" => "Password does not meets requirements/alert-danger"]);
		
		else if (pwSanitizeBeforeChange($_POST["password"]))
			render("change_pw.php", ["title" => "Reset Password", "verified" => true, "alert" => "Password does not meets requirements/alert-danger"]);
		
		else if ($_POST["password"] != $_POST["confirmation"])
			render("change_pw.php", ["title" => "Reset Password", "verified" => true, "alert" => "Password does not match/alert-danger"]);
			
		else {
			// change password for user
			db::query("UPDATE pacausrs SET usrPwdHash = ? WHERE usrID = ?", password_hash($_POST["password"], PASSWORD_DEFAULT), $_SESSION["OTP_ID"]);
			
			// expire token 
			db::query("UPDATE token SET timestamp = ? WHERE userID = ?", '0000-00-00 00:00:00', $_SESSION["OTP_ID"]);
			
			// remove stored user ID
			unset($_SESSION["OTP_ID"]);
			
			render("login_form.php", ["title" => "Log In", "alert" => "Password changed successfully!/alert-success"]);
		}
	}
	
	// post request from OTP.php
	if (isset($_POST["submit_OTP"])) {
		
		$res = db::query("SELECT * FROM token WHERE userID = ?", $_SESSION["OTP_ID"])[0];
		
		// check if OTP expired
		if (strtotime($res["timestamp"]) < strtotime("-5 minutes")) {
			render("OTP.php", ["title" => "Login Verification", "alert" => "OTP has expired, please request for a new OTP./alert-danger"]);
		}
		
		// verify OTP
		if ($_POST["OTP"] == $res["OTP"]) {
			
			// log successful OTP verification
			logging::type("OTP", [1, "reset"]);
			
			render("change_pw.php", ["title" => "Reset Password", "verified" => true]);
		}
		else {
			
			// log failed OTP verification
			logging::type("OTP", [0, "reset"]);
			
			render("OTP.php", ["title" => "Password Reset", "alert" => "Incorrect OTP entered, please try again./alert-danger"]);
		}
	}
	
	// post request from OTP.php
	if (isset($_POST["resend_OTP"])) {
		
		// check for and delete previous OTP
		$res = db::query("SELECT * FROM token WHERE userID = ?", $_SESSION["OTP_ID"]);
		if ($res) {
			db::query("DELETE FROM token WHERE userID=?", $_SESSION["OTP_ID"]);
		}
			
		// generate new OTP and send to user
		$OTP = generateOTP();
		db::query("INSERT INTO token (userID, OTP) VALUES(?, ?)", $_SESSION["OTP_ID"], $OTP);
		
		$row = db::query("SELECT * FROM pacausrs WHERE usrID=?", $_SESSION["OTP_ID"])[0];
		$content = "<p>
				Dear ". $row["usrFullName"] . ", 
				<br>
				<br>
				You have recently made a password reset request.
				<br>
				Please enter the OTP below when prompted.
				<br>
				<br>
				<b>OTP: " . $OTP . "</b>
				<br>
				<br>
				Thank you for shopping with us!
				<br>
				<img src='cid:logo'>
				<br>
				<br>
				<br>
				<small>If this was not done by you, no further action is required on your part.</small>
			</p>";
			
		sendMail($row['usrEmailAddr'], 'Password Reset', $content);
		
		render("OTP.php", ["title" => "Password Reset", "userID" => $row["usrID"], "alert" => "OTP has been sent, please check your email./alert-info"]);
	}
	//pre-sanitize email
	//check if email contains special character
	if (emailSanitize($_POST["email"]))
		render("reset_form.php", ["title" => "reset", "alert" => "invalid email/alert-danger"]);
	else{
	// check if email exists
		if (isset($_POST["email"])) {
			$rows = db::query("SELECT * FROM pacausrs WHERE usrEmailAddr = ?", $_POST['email']);
			if (empty($rows)) {
				render("change_pw.php", ["title" => "Reset Password", "alert" => "Email not found./alert-danger"]);
			}
			
			// check for and delete previous OTP
			$row = $rows[0];
			$res = db::query("SELECT * FROM token WHERE userID = ?", $row["usrID"]);
			if ($res) {
				db::query("DELETE FROM token WHERE userID=?", $row["usrID"]);
			}
				
			// generate new OTP and send to user
			$OTP = generateOTP();
			db::query("INSERT INTO token (userID, OTP) VALUES(?, ?)", $row["usrID"], $OTP);
			
			$content = "<p>
						Dear ". $row["usrFullName"] . ", 
						<br>
						<br>
						You have recently made a password reset request.
						<br>
						Please enter the OTP below when prompted.
						<br>
						<br>
						<b>OTP: " . $OTP . "</b>
						<br>
						<br>
						Thank you for shopping with us!
						<br>
						<img src='cid:logo'>
						<br>
						<br>
						<br>
						<small>If this was not done by you, no further action is required on your part.</small>
					</p>";
					
			sendMail($row['usrEmailAddr'], 'Password Reset', $content);
			
			$_SESSION["OTP_ID"] = $row["usrID"];
			render("OTP.php", ["title" => "Password Reset", "reset" => true]);
		}
	}
}

?>