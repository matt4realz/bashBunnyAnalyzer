<?php

// configuration
require("../includes/config.php");

if ($_SERVER["REQUEST_METHOD"] == "GET") {
	// Get user's cart items
	$usrID = $_SESSION["id"];
	$paymentStatus = 0;
	$cartItems = db::query("SELECT * FROM pacatransaction WHERE usrID = $usrID AND paymentStatus = $paymentStatus");
	render("cart_view.php", ["title" => "View Cart", "cartItems" => $cartItems]);

} 

else if ($_SERVER["REQUEST_METHOD"] == "POST") {
	if(isset($_POST["btnRemove"])){
		$transactionID = $_POST["btnRemove"];
		$res = db::query("DELETE FROM pacatransaction WHERE pacaTransactionID = $transactionID");
		
		if($res == 1){
			redirect('/cart.php');
		}
	}
}
?>