<?php

	// configuration
	require("../includes/config.php");
	include_once ("../includes/config.php");

	if ($_SERVER["REQUEST_METHOD"] == "GET") {
		render("payment_view.php", ["title" => "Payment"]);

	}else if ($_SERVER["REQUEST_METHOD"] == "POST"){
			
		if(isset($_POST["btnCheckout"])){
			$usrID = $_SESSION["id"];
			$status = 0;
			$totalPrices = db::query("SELECT totalPrice FROM pacatransaction WHERE usrID = $usrID AND paymentStatus = $status");
			render("payment_view.php", ["title" => "Payment", "totalPrices" => $totalPrices]);
		}
		
	}

?>
