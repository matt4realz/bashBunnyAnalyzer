<?php

// configuration
require("../includes/config.php");


if ($_SERVER["REQUEST_METHOD"] == "GET") {
    render("login_form.php", ["title" => "Log In"]);

} else if ($_SERVER["REQUEST_METHOD"] == "POST") {
	
	// post request from OTP.php
	if (isset($_POST["submit_OTP"])) {

		$res = db::query("SELECT * FROM token WHERE userID = ?", $_SESSION["OTP_ID"]);
		
		// check if OTP found
		if (!empty($res)) {
			$res = $res[0];
		}
		
		// check if OTP expired
		if (strtotime($res["timestamp"]) < strtotime("-5 minutes")) {
			render("OTP.php", ["title" => "Login Verification", "alert" => "OTP has expired, please request for a new OTP./alert-danger"]);
		}
		
		// verify OTP
		if ($_POST["OTP"] == $res["OTP"]) {
			
			// log user in
			$row = db::query("SELECT * FROM pacausrs WHERE usrID = ?", $_SESSION["OTP_ID"])[0];
            $_SESSION["id"] = $row["usrID"];
            $_SESSION["role"] = $row["UsrIsAdmin"];
            
			// log successful login
			db::query("INSERT INTO pacausrlogs (usrEmailAddr, fail) VALUES(?, ?)", $row["usrEmailAddr"], 0);
			
			// log successful OTP verification
			logging::type("OTP", [1, "login"]);
			
			// expire token 
			db::query("UPDATE token SET timestamp = ? WHERE userID = ?", '1990-01-01 01:01:01', $_SESSION["OTP_ID"]);
			
			// remove stored user id
			unset($_SESSION["OTP_ID"]);
			
			// redirect user
            if ($_SESSION["role"] == 1)
                redirect("/adminPortal.php");
            else
                redirect("/shopWomen.php");
		}
		else {
			// log failed OTP verification
			logging::type("OTP", [0, "login"]);
			render("OTP.php", ["title" => "Login Verification", "alert" => "Incorrect OTP entered, please try again./alert-danger"]);
		}
	}
	
	// post request from OTP.php
	if (isset($_POST["resend_OTP"])) {
		
		// check for and delete previous OTP
		$res = db::query("SELECT * FROM token WHERE userID = ?", $_SESSION["OTP_ID"]);
		if ($res) {
			db::query("DELETE FROM token WHERE userID=?", $_SESSION["OTP_ID"]);
		}
			
		// generate new OTP and send to user
		$OTP = generateOTP();
		db::query("INSERT INTO token (userID, OTP) VALUES(?, ?)", $_SESSION["OTP_ID"], $OTP);
		
		$row = db::query("SELECT * FROM pacausrs WHERE usrID=?", $_SESSION["OTP_ID"])[0];
		$content = "<p>
					Dear ". $row["usrFullName"] . ", 
					<br>
					<br>
					Please use the following OTP to login to your account.
					<br>
					<br>
					<b>OTP: " . $OTP . "</b>
					<br>
					<br>
					Thank you for shopping with us!
					<br>
					<img src='cid:logo'>
					<br>
					<br>
					<br>
					<small>If this was not you, no further action is required on your part.</small>
				</p>";
				
	
		sendMail($row['usrEmailAddr'], 'Login Verification', $content);
		
		render("OTP.php", ["title" => "Login Verification", "alert" => "OTP has been sent, please check your email./alert-info"]);
	}
	
	
	// check if email is empty
	if (empty($_POST["email"]))
		render("login_form.php", ["title" => "Log In", "alert" => "Please enter your email/alert-danger"]);
	
	// check if password is empty
	if (empty($_POST["password"]))
		render("login_form.php", ["title" => "Log In", "alert" => "Please enter your password/alert-danger"]);
	
	//check if password contains special char
	if (pwSanitizeBeforeChange($_POST["password"]))
		render("login_form.php", ["title" => "Log In", "alert" => "Password does not meet requirements/alert-danger"]);
	
	//check if email contains special character
	if (emailSanitize($_POST["email"]))
		render("login_form.php", ["title" => "Log In", "alert" => "invalid email/alert-danger"]);
	
	// check if client made > 5 unsuccesful login attempts in past 30 mins
    $rows = db::query("SELECT * FROM pacausrlogs WHERE usrEmailAddr = ?", $_POST["email"]);

    $attempts = [];
    foreach ($rows as $row) {
        // filter past 30mins results
        if (strtotime($row["usrLoginDateTime"]) > strtotime("-30 minutes")) {
            // store unsuccesful login attempts
            if ($row["fail"] == 1) {
                array_push($attempts, $row);
            }
        }
    }

    if (count($attempts) >= 5) {
		render("login_form.php", ["title" => "Log In", "alert" => "Amount of login attempts exceeded, please try again later./alert-danger"]);
    } 
	else {
        // query database for user
        $rows = db::query("SELECT * FROM pacausrs WHERE usrEmailAddr = ?", $_POST['email']);

        if (count($rows) == 1) {
            $row = $rows[0];

            // verify password
            if (password_verify($_POST["password"], $row["usrPwdHash"])) {
				
				// check for and delete expired OTP
				$res = db::query("SELECT * FROM token WHERE userID = ?", $row["usrID"]);
				if ($res) {
					if (strtotime($res[0]["timestamp"]) < strtotime("-5 minutes")) {
						db::query("DELETE FROM token WHERE userID=?", $row["usrID"]);
						
						// generate new OTP and send to user
						$OTP = generateOTP();
						db::query("INSERT INTO token (userID, OTP) VALUES(?, ?)", $row["usrID"], $OTP);
						
						$content = "<p>
									Dear ". $row["usrFullName"] . ", 
									<br>
									<br>
									Please use the following OTP to login to your account.
									<br>
									<br>
									<b>OTP: " . $OTP . "</b>
									<br>
									<br>
									Thank you for shopping with us!
									<br>
									<img src='cid:logo'>
									<br>
									<br>
									<br>
									<small>If this was not you, no further action is required on your part.</small>
								</p>";
						
			
						sendMail($_POST['email'], 'Login Verification', $content);
					}
				}
				
				$_SESSION["OTP_ID"] = $row["usrID"];
				render("OTP.php", ["title" => "Login Verification"]);
            }
            // incorrect password
            else {
                // log unsuccessful login attempt
                db::query("INSERT INTO pacausrlogs (usrEmailAddr, fail) VALUES(?, ?)", $_POST['email'], 1);

                render("login_form.php", ["title" => "Log In", "alert" => "Invalid email or password/alert-danger"]); 
            }
        }
    }
    redirect("/");
}
?>
