<!-- Women Shop Item Showcase -->
<div class="container">

	<?php
		if($items){
			
			foreach($items as $details){
			
				echo "<div class='row mt-5'>";
				echo "<div class='col-md-6'>";
				echo "<img class='card-img-top' src='data:image/jpeg;base64,".base64_encode($details['pacaItemImage'])."'>";
				echo "</div>";
				echo "<div class='col-md-6'>";
				echo "<h2>".$details["pacaItemName"]."</h2>";
				echo "<p style='font-size:18px;'>".$details["pacaItemDescription"]."</p>";
				echo "<p style='font-size:24px;'>$".$details["pacaItemPrice"]."</p>";				
				echo "<form method='POST' action='/itemDetails.php'>";
				echo "<div class='form-group'>";
				echo "<label for='selQuantity'>Quantity</label>";				
				echo "<div class='row'>";				
				echo "<div class='col-md-6'>";
				
				
				if ($details["pacaItemStock"] == 0) {
					echo "<select name='selQuantity' class='form-control' id='selQuantity' disabled>";
					echo "<option value='0'>Out of Stock</option>";
					echo "</select>";
					echo "</div>";
					echo "<div class='col-md-6'>";			
					echo "<button class='btn btn-primary float-right' type='submit' name='btnAddToCart' disabled value='".$details["pacaItemID"]."'>Add to Cart</button>";
				}
				else {
					echo "<select name='selQuantity' class='form-control' id='selQuantity'>";
					for ($i=1; $i<=$details["pacaItemStock"]; $i++) {
						echo "<option value=" . $i .">" . $i . "</option>";
					}	
					echo "</select>";
					echo "</div>";
					echo "<div class='col-md-6'>";			
					echo "<button class='btn btn-primary float-right' type='submit' name='btnAddToCart' value='".$details["pacaItemID"]."'>Add to Cart</button>";
				}
				echo "</div>";				
				echo "</div>";
				echo "</form>";				
				echo "</div>";
				echo "</div>";
			}
			
		}
	?>
</div>
</div>