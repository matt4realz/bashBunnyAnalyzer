<!-- Masthead -->
<header class="masthead" style="background-image: url('img/success.jpg');">
	<div class="container h-100">
		<div class="row h-100 align-items-center">
			<div class="col-12 float-left">
			<h1>Account Registered!</h1>
			<p class="lead">Please check your email for instructions to login.</p>
			</div>
		</div>
	</div>
</header>