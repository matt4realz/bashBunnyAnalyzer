<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
	
  
  <!-- Bootstrap core CSS -->
  <link href="/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom fonts for this template -->
  <link href="/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="/vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template -->
  <link href="css/landing-page.min.css" rel="stylesheet">
  <link href="css/cartStyle.css" rel="stylesheet">
  <link href="css/paymentStyle.css" rel="stylesheet">
  <link href="css/shopStyle.css" rel="stylesheet">
  <link rel="icon" type="image/png" href="../img/favicon.png">
  
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="js/scripts-header.js"></script>
  <script src="js/scripts-adminPortal.js"></script>
  <script src="https://js.stripe.com/v3/"></script>
  
  <?php if (isset($title)): ?>
		<title>PacaPaca - <?= htmlspecialchars($title) ?></title>
	<?php else: ?>
		<title>PacaPaca</title>
	<?php endif ?>
  
</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-light bg-light static-top">
    <div class="container">
	  <?php
		if (!isset($_SESSION["id"])) {
			echo
			"<a class=\"navbar-brand\" href=\"index.php\">
				<img src=\"img/title.png\">
			</a>
			<table>
				<td><a class='btn btn-primary' name='login' id='login' href='login.php'>Sign In</a></td>
				<td><a class='btn btn-primary' name='signup' id='signup' href='signup.php'>Sign Up</a></td>
			</table>";
		}
		else if ($_SESSION["role"] == 1) {
			echo
			"<a class=\"navbar-brand\" href=\"adminPortal.php\">
				<img src=\"img/title.png\">
			</a>
			<table>
				<tr>
					<td><a class='btn btn-link' name='adminPortal' id='adminPortal' href='adminPortal.php'>Account Management</a></td>
					<td><a class='btn btn-link' name='itemManagement' id='itemManagement' href='itemManagement.php'>Item Management</a></td>
				</tr>
			</table>
			
			<table>
				<tr>
					<td class=\"dropdown\">
						<a href=\"#\" data-toggle=\"dropdown\">
							<i class=\"fas fa-user-circle\"></i>
						</a>
						<ul class=\"dropdown-menu\">
						  <li><a href=\"#\">My Profile</a></li>
						  <li><a href=\"logout.php\">Logout</a></li>
						</ul>
					</td>
				</tr>
			</table>";
		}
		else {
			echo
			"<a class=\"navbar-brand\" href=\"index.php\">
				<img src=\"img/title.png\">
			</a>
			<table>
				<tr>
					<td><a class='btn btn-link' href='shopWomen.php'>Women</a></td>
					<td><a class='btn btn-link' href='shopMen.php'>Men</a></td>
					<td><a class='btn btn-link' href='shopKids.php'>Kids</a></td>
				</tr>
			</table>
 
			<table>
				<tr>
					<td class=\"dropdown\">
						<a href=\"#\" data-toggle=\"dropdown\">
							<i class=\"fas fa-user-circle\"></i>
						</a>
						<div class=\"dropdown-menu shadow dropdown-menu-right animated--grow-in\" role=\"menu\">
							<a class=\"dropdown-item\" role=\"presentation\" href=\"/profile.php\">
								<i id=\"logout\" class=\"fas fa-user fa-sm fa-fw mr-2 text-gray-400\"></i>&nbsp;Update Profile</a>
							<a class=\"dropdown-item\" role=\"presentation\" href=\"/change-password.php\">
								<i id=\"logout\" class=\"fas fa-lock fa-sm fa-fw mr-2 text-gray-400\"></i>&nbsp;Change Password</a>
							<a class=\"dropdown-item\" role=\"presentation\" href=\"/logout.php\">
								<i id=\"logout\" class=\"fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400\"></i>&nbsp;Logout</a>
						</div>
					</td>
					<td>
						<a class='btn btn-link' href=\"cart.php\">
							<i class=\"fas fa-shopping-cart\"></i>
						</a>
					</td>
				</tr>
			</table>";
		}
	  ?>
    </div>
  </nav>
	<div class="alert alert-dismissible fade collapse" role="alert" id="info"><strong></strong></div>
	<?php if (isset($alert)) { 
		echo '<div style="display: none;" id="alert">' . htmlspecialchars($alert) . '</div>';
	} ?>
