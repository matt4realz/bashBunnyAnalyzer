<section class="call-to-action text-white text-center">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-xl-9 mx-auto">
          <h1 class="mb-4">Sign In!</h1>
        </div>
      </div>
    </div>
  </section>

<div class="container">
	<div class="row justify-content-center">
		<div class="p-5 col-lg-6">
			<div class="text-center">
				<h3 class="text-dark mb-4">Login</h3>
			</div>
			<form class="user" method="post" action="/login.php">
				<div class="form-group"><strong>Email:</strong><input class="form-control" type="email" id="login" name="email" aria-describedby="emailHelp" required></div>
				<div class="form-group"><strong>Password:</strong><input class="form-control" type="password" id="login" name="password" required></div>
				<button class="btn btn-primary btn-block text-white" name="submit" type="submit">Login</button>
			</form>
			<hr>
			<div class="text-center"><a class="small" name="resetAcct" id="resetAcct" href="reset.php">Forgot Password?</a></div>
			<div class="text-center"><a class="small" name="createAcct" id="createAcct" href="signup.php">Create an Account!</a></div>
		</div>
	</div>
</div>
