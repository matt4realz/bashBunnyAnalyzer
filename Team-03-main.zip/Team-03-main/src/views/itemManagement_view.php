<div class="container">
	<div class="row pt-5">
		<div class="col-md-6">
			<h2>Item Management</h2>
		</div>
		<div class="col-md-6">
			<!-- Button to open the new item modal -->
			<button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#newItemModal">
			  New Item
			</button>

			<!-- New item modal-->
			<div class="modal" id="newItemModal">
				<div class="modal-dialog">
					<div class="modal-content">

						<!-- Modal header -->
						<div class="modal-header">
						<h4 class="modal-title">New Item</h4>
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						</div>
						
						<form method="POST" action="itemManagement.php" enctype="multipart/form-data">
						<!-- Modal body -->
						<div class="modal-body">
							<?php
							if(isset($error)){
								echo "<div class='alert alert-danger'>";
								echo $error;
								echo "</div>";
							}
							?>
							<div class="row form-group">
								<div class="col-md-4"><label for="itemName">Item Name:</label></div>
								<div class="col-md-8"><input type="text" class="form-control" id="itemName" name="itemName"></div>
							</div>
							<div class="row form-group">
								<div class="col-md-4"><label for="itemImage">Item Image:</label></div>
								<div class="col-md-8"><input type="file" class="form-control-file" id="itemImage" name="itemImage"></div>
							</div>
							<div class="row form-group">
								<div class="col-md-4"><label for="itemDesc">Description:</label></div>
								<div class="col-md-8"><textarea class="form-control" rows="5" id="itemDesc" name="itemDesc"></textarea></div>
							</div>
							<div class="row form-group">
								<div class="col-md-4"><label for="selCategory">Category:</label></div>
								<div class="col-md-8">
								<select id="selCategory" class="form-control" name="selCategory">
									<option value="women">Women</option>
									<option value="men">Men</option>
									<option value="kids">Kids</option>
								</select>
								</div>
							</div>
							<div class="row form-group">
								<div class="col-md-4"><label for="itemPrice">Price:</label></div>
								<div class="col-md-8"><input type="number" class="form-control" id="itemPrice" name="itemPrice"></div>
							</div>
							<div class="row form-group">
								<div class="col-md-4"><label for="itemStock">Stock:</label></div>
								<div class="col-md-8"><input type="number" class="form-control" id="itemStock" name="itemStock"></div>
							</div>
						</div>

						<!-- Modal footer -->
						<div class="modal-footer">
						<button type="submit" id="btnAddItem" class="btn btn-primary btnAddItem" name="btnAddItem">Add</button>
						</div>
						</form>
					</div>
				</div>
			</div>
			<?php 
			if(isset($error)){
				echo "<script>";
				echo '$(document).ready(function(){';
				echo '$("#newItemModal").modal("show");';
				echo '});';
				echo "</script>";
			}
			?>
		</div>
	</div>
	
	<!-- Retrieve item records -->
			<?php
	// Create & Check connection 
	//include 'dbConn.php';
		
	//$result = mysqli_query($conn, "SELECT * FROM PacaShop");
	
	/* Table header */
	echo "<table class='table' id='itemTable'>";
	echo "<tr>";
	echo "<th>S/N</th>";
	echo "<th>Item Name</th>";
	echo "<th>Description</th>";
	echo "<th>Price</th>";
	echo "<th>Stock</th>";
	echo "<th>Action</th>";
	echo "</tr>";
	
	if($shopItems){
		foreach($shopItems as $shopItem){
			echo "<tr>";
			echo "<td class='tt'>". $shopItem["pacaItemID"] ."</td>";
			echo "<td class='tt'>". $shopItem["pacaItemName"] ."</td>";
			echo "<td class='tt'>". $shopItem["pacaItemDescription"] ."</td>";
			echo "<td class='tt'>$". $shopItem["pacaItemPrice"] ."</td>";
			echo "<td class='tt'>". $shopItem["pacaItemStock"] ."</td>";
			echo "<td class='tt'><button type='button' id='btnEditItem' class='btn btn-link btnEditItem' name='btnEditItem'>Edit</button>";
			echo "<button type='button' id='btnRemoveItem' class='btn btn-link btnRemoveItem' name='btnRemoveItem'>Remove</button></td>";
			echo "</tr>";
		}
	}
	
	echo"</table>";
	?>
	
	<!-- Edit item modal -->
	<div class="modal" id="editItemModal">
		<div class="modal-dialog">
			<div class="modal-content">
				<!-- Modal header -->
				<div class="modal-header">
				<h4 class="modal-title">Edit Item</h4>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>

				<form method="POST" action="itemManagement.php" enctype="multipart/form-data">
				<!-- Modal body -->
				<div class="modal-body">
					<?php
					if(isset($editError)){
						echo "<div class='alert alert-danger'>";
						echo $editError;
						echo "</div>";
					}
					?>
					<div class="form-group"><input type="hidden" class="form-control" id="editItemID" name="editItemID"></div>
					<div class="row form-group">
						<div class="col-md-4"><label for="editItemName">Item Name:</label></div>
						<div class="col-md-8"><input type="text" class="form-control" id="editItemName" name="editItemName"></div>
					</div>
					<div class="row form-group">
						<div class="col-md-4"><label for="editItemDesc">Description:</label></div>
						<div class="col-md-8"><textarea class="form-control" rows="5" id="editItemDesc" name="editItemDesc"></textarea></div>
					</div>
					<div class="row form-group">
						<div class="col-md-4"><label for="selEditCategory">Category:</label></div>
						<div class="col-md-8">
						<select id="selCategory" class="form-control" name="selEditCategory">
							<option value="women">Women</option>
							<option value="men">Men</option>
							<option value="kids">Kids</option>
						</select>
						</div>
					</div>
					<div class="row form-group">
						<div class="col-md-4"><label for="editItemPrice">Price:</label></div>
						<div class="col-md-8"><input type="number" class="form-control" id="editItemPrice" name="editItemPrice"></div>
					</div>
					<div class="row form-group">
						<div class="col-md-4"><label for="editItemStock">Stock:</label></div>
						<div class="col-md-8"><input type="number" class="form-control" id="editItemStock" name="editItemStock"></div>
					</div>
				</div>

				<!-- Modal footer -->
				<div class="modal-footer">
				<button type="submit" class="btn btn-primary btnSave" id="btnSave" name="btnSave">Save</button>
				</div>
				</form>

			</div>
		</div>
	</div>
	<?php 
	if(isset($editError)){
		echo "<script>";
		echo '$(document).ready(function(){';
		echo '$("#editItemModal").modal("show");';
		echo '});';
		echo "</script>";
	}
	?>
	
	<!-- Remove item modal -->
	<div class="modal" id="removeItemModal">
		<div class="modal-dialog">
			<div class="modal-content">
				<!-- Modal header -->
				<div class="modal-header">
				<h4 class="modal-title">Remove Item</h4>
				</div>
				
				<form method="POST" action="itemManagement.php">
				<!-- Modal body -->
				<div class="modal-body">
				<div class="form-group"><input type="hidden" class="form-control" id="removeItemID" name="removeItemID"></div>
				Are you sure you want to remove this item?
				</div>

				<!-- Modal footer -->
				<div class="modal-footer">
				<button type="submit" id="btnCfmRemove" class="btn btn-primary btnCfmRemove" name="btnCfmRemove">Yes</button>
				<button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
				</div>
				</form>
			</div>
		</div>
	</div>
</div>