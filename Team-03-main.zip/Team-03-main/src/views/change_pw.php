<?php 
	if (isset($verified)) { ?>
		<div class="container">
			<div class="row justify-content-center">
				<div class="p-5 col-lg-6">
					<div class="text-center">
						<h3 class="text-dark mb-4">Please Enter a new password</h3>
					</div>
					<form class="user" method="post" action="/reset.php" onsubmit="validate(this);">
						<div class="col-lg-12"><strong>Password:</strong><input class="form-control" type="password" id="passReq" name="password" required></div>
						<br>
						<div class="col-lg-12"><strong>Confirm Password:</strong><input class="form-control" type="password" id="confirmation" name="confirmation" required></div>
						<br>
						<button class="btn btn-primary btn-block text-white" type="submit" name="reset">Submit</button>
					</form>
				</div>
			</div>
		</div>
<?php } else if (isset($change_pw)) { ?>
			<div class="container">
			<div class="row justify-content-center">
				<div class="p-5 col-lg-6">
					<div class="text-center">
						<h3 class="text-dark mb-4">Please Enter a new password</h3>
					</div>
					<form class="user" method="post" action="/change-password.php" onsubmit="validate(this);">
					<br>
					<div class="col-lg-12"><strong>Password:</strong><input class="form-control" type="password" id="passReq" name="password_new" required></div>
					<div class="col-lg-12"><strong>Confirm Password:</strong><input class="form-control" type="password" id="confirmation" name="confirmation" required></div>
					<br>
						<button class="btn btn-primary btn-block text-white" type="submit">Submit</button>
					</form>
				</div>
			</div>
		</div>
<?php } else { ?>
			<div class="container">
				<div class="row justify-content-center">
					<div class="p-5 col-lg-6">
						<div class="text-center">
							<h3 class="text-dark mb-4">Reset Password</h3>
						</div>
						<form class="user" method="post" action="/reset.php">
							<div class="form-group"><strong>Email:</strong><input class="form-control" type="email" name="email" aria-describedby="emailHelp" required></div>
							<button class="btn btn-primary btn-block text-white" type="submit">Submit</button>
						</form>
					</div>
				</div>
			</div>
	<?php } ?>