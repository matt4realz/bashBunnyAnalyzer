<form action="charge.php" method="POST" id="paymentForm">
<div class="container mt-2">
	<div class="row">
		<div class="col-md-9">
			<!-- Shipping Address Panel -->
			<div class="panel panel-default">
			<div class="panel-header"><h5 class="p-1">Shipping Address</h5></div>
			<div class="panel-body p-2">
				<div class="row">
					<div class="form-group col-md-6">
						<label for="unitNumber">Unit Number*</label>
						<input type="text" class="form-control" id="unitNumber" name="unitNumber">
					</div>
					<div class="form-group col-md-6">
						<label for="postalCode">Postal Code*</label>
						<input type="text" class="form-control" id="postalCode" name="postalCode">
					</div>
				</div>		
				<div class="form-group">
					<label for="address">Address*</label>
					<input type="text" class="form-control" id="Address" name="Address">
				</div>
			</div>
			</div>
			
			<!-- Payment Details Panel -->
			<div class="panel panel-default">
			<div class="panel-header"><h5 class="p-1">Payment Details</h5></div>
			<div class="panel-body p-2">
				<!-- Display errors returned by createToken -->
				<div id="paymentResponse"></div>
			
				<!-- Payment Form -->
				<div class="form-group">
					<label for="card_number">Card Number*</label>
					<div id="card_number" class="form-control"></div>
				</div>
				<div class="row">
					<div class="form-group col-md-4">
						<label for="selMonth">Expiry Date (MM/YYYY)*</label>
						<div id="card_expiry" class="form-control"></div>
					</div>
					<div class="form-group col-md-4">
						<label for="card_cvc">CVC*</label>
						<div id="card_cvc" class="form-control"></div>
					</div>
				</div>		
				<div class="form-group">
					<label for="name">Name on Card*</label>
					<input type="text" class="form-control" id="name" name="name">
				</div>
				<div class="form-group">
					<label for="email">Email*</label>
					<input type="email" name="email" id="email" class="form-control">
				</div>
				
			</div>
			</div>
		</div>
		<div class="col-md-3">
			<div id="order-summary" class="p-2">
				<h4 class="pt-1">Order Summary</h4>
				<hr>
				<div class="row">
					<p class="order-subtitle col-md-6">Subtotal:</p>
					<p class="col-md-6">
						<?php
						if($totalPrices){
							$subtotal = 0;
							foreach($totalPrices as $price){
								$subtotal += $price["totalPrice"];		
							}
							echo "SGD $".$subtotal;
						}
						?>
					</p>
				</div>
				<div class="row">
					<p class="order-subtitle col-md-6">Shipping:</p>
					<p class="col-md-6">$3</p>
				</div>
				<hr>
				<div class="row mb-2">
					<h4 class="col-md-6">Total</h4>
					<h4 class="col-md-6">
					<?php 
					if($totalPrices){
						$subtotal = 0;
						$shipping = 3;
						foreach($totalPrices as $price){
							$subtotal += $price["totalPrice"];
						}
						$total = $subtotal + $shipping;
						echo "SGD $".$total;
					}else{
						echo "-";
					}
					?>
					</h4>
				</div>
				<button type="submit" id="payBtn" class="btn btn-primary btn-block payBtn" name="btnPayNow">Pay Now</button>
			</div>
		</div>
	</div>
</div>
</form>
<!-- Stripe JS library -->
<script>
// Create an instance of the Stripe object
// Set your publishable API key
var stripe = Stripe('<?php echo STRIPE_PUBLISHABLE_KEY; ?>');

// Create an instance of elements
var elements = stripe.elements();

var style = {
    base: {
        fontWeight: 400,
        fontFamily: 'Roboto, Open Sans, Segoe UI, sans-serif',
        fontSize: '16px',
        lineHeight: '1.4',
        color: '#555',
        backgroundColor: '#fff',
        '::placeholder': {
            color: '#888',
        },
    },
    invalid: {
        color: '#eb1c26',
    }
};

var cardElement = elements.create('cardNumber', {
    style: style
});
cardElement.mount('#card_number');

var exp = elements.create('cardExpiry', {
    'style': style
});
exp.mount('#card_expiry');

var cvc = elements.create('cardCvc', {
    'style': style
});
cvc.mount('#card_cvc');

// Validate input of the card elements
var resultContainer = document.getElementById('paymentResponse');
cardElement.addEventListener('change', function(event) {
    if (event.error) {
        resultContainer.innerHTML = '<p style="color:red;">'+event.error.message+'</p>';
    } else {
        resultContainer.innerHTML = '';
    }
});

// Get payment form element
var form = document.getElementById('paymentForm');

// Create a token when the form is submitted.
form.addEventListener('submit', function(e) {
    e.preventDefault();
    createToken();
});

// Create single-use token to charge the user
function createToken() {
    stripe.createToken(cardElement).then(function(result) {
        if (result.error) {
            // Inform the user if there was an error
            resultContainer.innerHTML = '<p style="color:red;">'+result.error.message+'</p>';
			console.log("test1"+result.error.message);
        } else {
            // Send the token to your server
            stripeTokenHandler(result.token);
        }
    });
}

// Callback to handle the response from stripe
function stripeTokenHandler(token) {
    // Insert the token ID into the form so it gets submitted to the server
    var hiddenInput = document.createElement('input');
    hiddenInput.setAttribute('type', 'hidden');
    hiddenInput.setAttribute('name', 'stripeToken');
    hiddenInput.setAttribute('value', token.id);
    form.appendChild(hiddenInput);
	
    // Submit the form
    form.submit();
}
</script>
