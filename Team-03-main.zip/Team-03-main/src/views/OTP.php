<div class="container">
    <div class="row justify-content-center">
        <div class="p-5 col-6">
            <div class="text-center">
                <h3 class="text-dark mb-4">Login: One Time Pin (OTP)</h3>
            </div>
            <?php 
				if (isset($reset)) {
					echo "<form id=\"submit_otp\" method=\"post\" action=\"reset.php\" class=\" justify-content-center\">";
				}
				else {
					echo "<form id=\"submit_otp\" method=\"post\" action=\"login.php\" class=\" justify-content-center\">";
				}
				
			?>
                <p class="text-center">Please enter the OTP sent to your email. <br> The OTP expires in 5 minutes.</p>
                <div class="form-group row">
                    <input class="form-control" type="text" name="OTP" required pattern="^[0-9A-Z]{8}$">
                </div>
                <button class="btn btn-primary btn-block text-white btn-user" type="submit" name="submit_OTP">Submit OTP</button>
                <button 
					class="btn btn-primary btn-block text-white btn-user" type="submit" name="resend_OTP" 
					onClick="removeRequired(this.form)">Resend OTP
				</button>
            </form>
        </div>
    </div>
</div>