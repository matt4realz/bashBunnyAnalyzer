  <section class="call-to-action text-white text-center">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-xl-9 mx-auto">
          <h1 class="mb-4">Sign Up!</h1>
        </div>
      </div>
    </div>
  </section>

	<div class="container">
    <div class="row justify-content-center">
        <div class="p-5 col-9">
            <div class="text-center">
                <h3 class="text-dark mb-4">Account Registration</h3>
            </div>
            <form id="register" method="post" action="signup.php" onsubmit="validate(this);" class=" justify-content-center">
                <div class="form-group row">
                    <div class="col-lg-6"><strong>Name:</strong><input class="form-control" type="text" name="name"></div>
                    <div class="col-lg-6"><strong>Email:</strong><input class="form-control" type="text" id="email" name="email"></div>
                </div>
                <div class="form-group row">
                    <div class="col-lg-12"><strong>Birthday:</strong><input class="form-control" type="date" name="BDay"></div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-6"><strong>Password:</strong><input class="form-control" type="password" id="passReq" name="password" ></div>
                    <div class="col-sm-6"><strong>Confirm Password:</strong><input class="form-control" type="password" id="confirmation" name="confirmation" ></div>
                </div>
                
				<br>
                <button class="btn btn-primary btn-block text-white btn-user" type="submit">Register</button>
            </form>
			<hr>
			<div class="text-center"><a class="small" name="signin2" id="signin2" href="login.php">Already have an account? Sign in!</a></div>
        </div>
    </div>
</div>
