<!-- Masthead -->
<header class="masthead" style="background-image: url('img/bg-men-masthead.jpg');">
	<div class="container h-100">
		<div class="row h-100 align-items-center">
			<div class="col-12 float-left">
			<h1>Men's Collection</h1>
			<p class="lead">Live your fashion dream</p>
			</div>
		</div>
	</div>
</header>
	
<!-- Men Shop Item Showcase -->
<div class="container">

	<?php
		if($items){
			
			$itemCount = 1;
			
			foreach($items as $item){
				if($itemCount % 4 == 1){
					echo "<div class='row mt-5 mb-2'>";
				}
				
				echo "<div class='col-sm-3'>";
				echo "<div class='card'>";
				echo "<img class='card-img-top' src='data:image/jpeg;base64,".base64_encode($item['pacaItemImage'])."'>";
				echo "<div class='card-body text-center'>";
				echo "<h5 class='card-title'>".$item["pacaItemName"]."</h5>";
				echo "<p class='card-text'>$".$item["pacaItemPrice"]."</p>";
				echo "<form method='POST' action='/itemDetails.php'>";
				echo "<button class='btn btn-link stretched-link' type='submit' name='btnViewDetails' value='".$item["pacaItemID"]."'>View More</button>";
				echo "</form>";
				echo "</div>";
				echo "</div>";
				echo "</div>";
				
				if($itemCount % 4 == 0){
					echo "</div>";
				}
				$itemCount++;
			}
		}
	?>
</div>
</div>