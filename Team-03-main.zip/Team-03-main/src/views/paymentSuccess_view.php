<div class="container">
	<div class="status">

			<h1>Thank you for shopping with us!</h1>
			<h2>Payment has been made successfully.</h2>
			<br>
			<h4>Payment Information</h4>
			<p><b>Transaction ID:</b> <?php echo $transactionID; ?></p>
			<p><b>Paid Amount:</b> SGD $<?php echo $paidAmount; ?></p>
	</div>
	<a href="index.php" class="btn-link">Back to Home</a>
</div>