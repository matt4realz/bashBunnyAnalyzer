<!-- Masthead -->
  <header class="masthead text-white text-center">
    <div class="overlay"></div>
    <div class="container">
		<div class="row">
			<div class="col-xl-9 mx-auto" style="float:left;">
				<h1 class="mb-5" style="float:left;">New Arrivals</h1>
			</div>
		</div>
		<div class="row">
			<div class="col-xl-8 mx-auto">
				<p style="font-size:20px; background-color:black; float:left; padding-left:10px; padding-right:10px">
				Autumn Collection
				</p>
			</div>
		</div>
		<div class="row">
			<div class="col-xl-9 mx-auto">
				<p style="font-size:2rem; float:left;">Up to 60% Off + <br>Extra 15% Cashback</p>
			</div>
		</div>
    </div>
  </header>

  <!-- Image Showcases -->
  <section class="showcase">
    <div class="container-fluid p-0">
      <div class="row no-gutters">

        <div class="col-lg-6 order-lg-2 text-white showcase-img" style="background-image: url('img/bg-women-masthead2.jpg');"></div>
        <div class="col-lg-6 order-lg-1 my-auto showcase-text">
          <h2>Women's Collection</h2>
          <p class="lead mb-0">Explore The Different Beauty</p>
        </div>
      </div>
      <div class="row no-gutters">
        <div class="col-lg-6 text-white showcase-img" style="background-image: url('img/bg-men-masthead.jpg');"></div>
        <div class="col-lg-6 my-auto showcase-text">
          <h2>Men's Collection</h2>
          <p class="lead mb-0">New Style New Attitude</p>
		</div>
      </div>
      <div class="row no-gutters">
        <div class="col-lg-6 order-lg-2 text-white showcase-img" style="background-image: url('img/bg-kid-masthead2.jpg');"></div>
        <div class="col-lg-6 order-lg-1 my-auto showcase-text">
          <h2>Kid's Collection</h2>
          <p class="lead mb-0">The Best Styles For Your Little Ones</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Testimonials -->
  <section class="testimonials text-center bg-light">
    <div class="container">
      <h2 class="mb-5">What customers are saying...</h2>
      <div class="row">
        <div class="col-lg-4">
          <div class="testimonial-item mx-auto mb-5 mb-lg-0">
            <img class="img-fluid rounded-circle mb-3" src="img/profile1.jpg" alt="">
            <h4>Shah B.</h4>
			<h6>Social Influencer</h6>
            <p class="font-weight-light mb-0">"Your products are still the best in the industry! Hope we have a continued partnership!"</p>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="testimonial-item mx-auto mb-5 mb-lg-0">
            <img class="img-fluid rounded-circle mb-3" src="img/profile2.jpg" alt="">
            <h4>Cao N.M</h4>
			<h6>Head of PR, Saek C. Beauty</h6>
            <p class="font-weight-light mb-0">"This is fantastic! Thanks so much guys! Super satisfactory experience everytime with you guys."</p>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="testimonial-item mx-auto mb-5 mb-lg-0">
            <img class="img-fluid rounded-circle mb-3" src="img/profile3.jpg" alt="">
            <h4>K. Nina</h4>
			<h6>Zofora, Singapore</h6>
            <p class="font-weight-light mb-0">"Thanks so much for making these awesome products! Consistent results every time we order from PacaPaca!"</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Call to Action -->
  <section class="call-to-action text-white text-center">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-xl-9 mx-auto">
          <h2 class="mb-4">Ready to get started? Sign up now!</h2>
        </div>
        <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
          <form>
            <div class="form-row">
              <div class="col-12 col-md-9 mb-2 mb-md-0">
                <input type="email" class="form-control form-control-lg" placeholder="Enter your email...">
              </div>
              <div class="col-12 col-md-3">
                <button type="submit" class="btn btn-block btn-lg btn-primary">Sign up!</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>