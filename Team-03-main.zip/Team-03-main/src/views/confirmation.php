<div class="container">
    <div class="row justify-content-center">
        <div class="p-5 col-9">
            <div class="text-center">
			<?php 
				if (isset($_SESSION["profile"]))
					echo "<h3 class=\"text-dark mb-4\">Please enter your password to continue</h3>";
				
				else 
					echo "<h3 class=\"text-dark mb-4\">Please enter your current password</h3>";
			?>
            </div>
			<div class="d-flex justify-content-center">
				<?php 
					if (isset($_SESSION["profile"]))
						echo "<form method=\"post\" action=\"/profile.php\" class=\"justify-content-center\">";
					
					else 
						echo "<form method=\"post\" action=\"/change-password.php\" class=\"justify-content-center\">";
				?>
					<div class="form-group row">
						<input class="form-control" type="password" name="password" placeholder="Password" required>
					</div>
					
					<button class="btn btn-primary btn-sm btn-block" type="submit">Submit</button>
				</form>
			</div>
        </div>
    </div>
</div>