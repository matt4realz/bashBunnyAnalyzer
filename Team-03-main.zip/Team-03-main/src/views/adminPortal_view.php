<div class="container">
	<div class="row pt-5">
		<div class="col-md-6">
			<h2>Account Management</h2>
		</div>
		<div class="col-md-6">
			<!-- Button to Open the Modal -->
			<button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#newAccModal">
			  New Account
			</button>

			<!-- The Modal -->
			<div class="modal" id="newAccModal">
				<div class="modal-dialog">
					<div class="modal-content">

						<!-- Modal Header -->
						<div class="modal-header">
						<h4 class="modal-title">New Account</h4>
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						</div>
						
						<form method="POST" action="adminPortal.php">
						<!-- Modal body -->
						<div class="modal-body">
							<?php
							if(isset($error)){
								echo "<div class='alert alert-danger'>";
								echo $error;
								echo "</div>";
							}
							?>
							
							<div class="row form-group">
								<div class="col-md-4"><label for="fullName">Full Name:</label></div>
								<div class="col-md-8"><input type="text" class="form-control fullName" id="fullName" name="fullName"></div>
							</div>
							<div class="row form-group">
								<div class="col-md-4"><label for="birthday">Birthday:</label></div>
								<div class="col-md-8"><input type="date" class="form-control birthday" id="birthday" name="birthday"></div>
							</div>
							<div class="row form-group">
								<div class="col-md-4"><label for="emailAddr">Email Address:</label></div>
								<div class="col-md-8"><input type="email" class="form-control emailAddr" id="emailAddr" name="emailAddr"></div>
							</div>
							<div class="row form-group">
								<div class="col-md-4"><label for="pwd">Password:</label></div>
								<div class="col-md-8"><input type="password" class="form-control pwd" id="pwd" name="pwd"></div>
							</div>
							<div class="row form-group">
								<div class="col-md-4"><label for="cfmPwd">Confirm Password:</label></div>
								<div class="col-md-8"><input type="password" class="form-control cfmPwd" id="cfmPwd" name="cfmPwd"></div>
							</div>
							<div class="row form-group">
								<div class="col-md-4"><label for="cfmPwd">Access Right:</label></div>
								<div class="col-md-8">
								<select id="selAccessRight" class="form-control" name="selAccessRight">
									<option value="admin">Admin</option>
									<option value="user">Normal User</option>
								</select>
								</div>
							</div>
						</div>

						<!-- Modal footer -->
						<div class="modal-footer">
						<button type="submit" id="btnAddAcc" class="btn btn-primary btnAddAcc" name="btnAddAcc">Add</button>
						</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<?php 
		if(isset($error)){
			echo "<script>";
			echo '$(document).ready(function(){';
			echo '$("#newAccModal").modal("show");';
			echo '});';
			echo "</script>";
		}
		?>
	</div>
	<!-- Retrieve account records -->
	<?php
	
	/* Table header */
	echo "<table class='table' id='accountTable'>";
	echo "<tr>";
	echo "<th>Full Name</th>";
	echo "<th>Date of Birth</th>";
	echo "<th>Email Address</th>";
	echo "<th>Account Type</th>";
	echo "<th>Action</th>";
	echo "</tr>";

	if($accounts){ 
		foreach($accounts as $account){
			echo "<tr>";
			echo "<td class='tt'>". $account["usrFullName"] ."</td>";
			echo "<td class='tt'>". $account["usrBirthday"] ."</td>";
			echo "<td class='tt'>". $account["usrEmailAddr"] ."</td>";
			
			if($account["UsrIsAdmin"] == 1){
				echo "<td class='tt'> Admin </td>";
			}else{
				echo "<td class='tt'> Normal User </td>";
			}
			?> 	
				<td class='tt'>
					<span data-toggle="modal" class="pl-3" data-target="#confirmation">
						<button type='button' id='btnDelete' class='btn btn-link btnDelete' value='<?= $account["usrID"]?>' onclick=getID(this.value); name='btnDelete'>
							Delete Account
						</button>
					</span>
					
					<div class="modal" id="confirmation">
						<div class="modal-dialog">
							<div class="modal-content">

								<div class="modal-header">
									<h4 class="modal-title">Confirmation</h4>
									<button type="button" class="close" data-dismiss="modal">&times;</button>
								</div>

								<div class="modal-body">Delete Account?</div>

								<div class="modal-footer">
									<?php
										$postArr = ["userID" => $account["usrID"]];
										$postArr["delete"] = "";
										$postObj = addslashes(json_encode($postArr));
									?>
									<button class="btn-sm btn-danger" onclick='post("/adminPortal.php", "<?= $postObj?>")'>Delete</button>
								</div>	
							</div>
						</div>
					</div>
				</td>
			</tr>
<?php	
		}
	}
	echo"</table>";
?>
