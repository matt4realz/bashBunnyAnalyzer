<div class="container">
    <div class="row justify-content-center">
        <div class="p-5 col-9">
            <div class="text-center">
                <h3 class="text-dark mb-4">Update Profile</h3>
            </div>
            <form id="register" method="post" action="profile.php" onsubmit="validate(this);" class=" justify-content-center">
                <div class="form-group row">
                    <div class="col-lg-6"><strong>Name: </strong><input class="form-control" type="text" name="name" <?php echo 'value="'.$name.'"';?>></div>
                    <div class="col-lg-6"><strong>Email: </strong><input class="form-control" type="text" name="email" <?php echo 'value="'.$email.'"';?>></div>
                </div>
                <div class="form-group row">
                    <div class="col-lg-12"><strong>Birthday: </strong><input class="form-control" type="date" name="bday" <?php echo 'value="'.$bday.'"';?>></div>
				</div>
				<br>
                <button class="btn btn-primary btn-block text-white btn-user" type="submit" name="profile" value="1">Update</button>
            </form>
		</div>
    </div>
</div>