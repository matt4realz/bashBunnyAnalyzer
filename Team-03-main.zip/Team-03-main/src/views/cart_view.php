<div class="container">
	<h1>Your Cart</h1>
	<div class="row">
		<div class="col-md-9">
		<table id="product-table" class="table">
			<thead>
				<tr>
					<td>Product</td>
					<td>Price</td>
					<td>Quantity</td>
					<td>Total</td>
					<td>Remove</td>
				</tr>
				<?php 
					if($cartItems){
						foreach($cartItems as $item){
							echo "<tr>";
							echo "<td>".$item["pacaItemName"]."</td>";
							echo "<td>$".$item["pacaItemPrice"]."</td>";
							echo "<td>".$item["quantity"]."</td>";
							echo "<td>$".$item["totalPrice"]."</td>";
							
							echo "<td>";
							echo "<form method='POST' action='/cart.php'>";
							echo "<button type='submit' class='btn' name='btnRemove' value='".$item["pacaTransactionID"]."'>&times;</button>";
							echo "</form>";
							echo "</td>";
							echo "</tr>";
						
						}
					}
				?>
			</thead>
			<tbody>
			</tbody>
		</table>
		</div>
		<div class="col-md-3">
		<section id="order-summary" class="p-1">
			<h4>Order Summary</h4>
			<hr>
			<div class="row">
				<p class="order-subtitle col-md-6">Subtotal:</p>
				<p class="col-md-6">
					<?php 
					if($cartItems){
						$subtotal = 0;
						foreach($cartItems as $item){
							$subtotal += $item["totalPrice"];		
						}
						echo "SGD $".$subtotal;
					}else{
						echo "-";
					}
					?>
				</p>
			</div>
			<div class="row">
				<p class="order-subtitle col-md-6">Shipping:</p>
				<p class="col-md-6">
					<?php 
					if($cartItems){
						echo "$3";
					}else{
						echo "-";
					}
					?>
				</p>
			</div>
			<hr>
			<div class="row">
				<h4 class="col-md-6">Total</h4>
				<h4 class="col-md-6">
					<?php 
					if($cartItems){
						$subtotal = 0;
						$shipping = 3;
						foreach($cartItems as $item){
							$subtotal += $item["totalPrice"];
						}
						$total = $subtotal + $shipping;
						echo "SGD $".$total;
					}else{
						echo "-";
					}
					?>
				</h4>
			</div>
			<form method="POST" action="payment.php">
				<?php
				if($cartItems){
					echo "<button type='submit' id='btnCheckout' class='btn btn-primary btn-block' name='btnCheckout'>Checkout</button>";
				}else{
					echo "<button type='submit' id='btnCheckout' class='btn btn-primary btn-block' name='btnCheckout' disabled>Checkout</button>";
				}
				?>
			</form>
		</section>
		</div>
	</div>
</div>