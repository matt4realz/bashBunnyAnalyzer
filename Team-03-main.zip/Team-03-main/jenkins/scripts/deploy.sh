#!/usr/bin/env sh

set -x
docker run -d -p 721:721 --name selTest2 -v /home/jenkins/jenkins-php-selenium-test//src:/var/www/html/pacapaca.sitict.net php:7.2-apache
sleep 1
set +x

echo 'Now...'
echo 'Visit http://localhost to see your PHP application in action.'

