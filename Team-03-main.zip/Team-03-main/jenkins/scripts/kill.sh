#!/usr/bin/env sh

set -x
docker kill selTest2 
docker rm selTest2 
